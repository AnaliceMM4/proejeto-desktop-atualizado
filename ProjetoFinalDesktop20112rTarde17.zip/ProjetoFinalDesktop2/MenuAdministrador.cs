﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace ProjetoFinalDesktop2
{
    public partial class MenuAdministrador : Form
    {
        public MenuAdministrador()
        {
            InitializeComponent();
           
        }


        private void Atualiza()
        {
            this.apolicesTableAdapter.Fill(this.corretoraDataSet.Apolices);
            // TODO: esta linha de código carrega dados na tabela 'corretoraDataSet.TabelaFIPE'. Você pode movê-la ou removê-la conforme necessário.
            this.tabelaFIPETableAdapter.Fill(this.corretoraDataSet.TabelaFIPE);
            // TODO: esta linha de código carrega dados na tabela 'corretoraDataSet.Modelo'. Você pode movê-la ou removê-la conforme necessário.
            this.modeloTableAdapter.Fill(this.corretoraDataSet.Modelo);
            // TODO: esta linha de código carrega dados na tabela 'corretoraDataSet.Marca'. Você pode movê-la ou removê-la conforme necessário.
            this.marcaTableAdapter.Fill(this.corretoraDataSet.Marca);
            // TODO: esta linha de código carrega dados na tabela 'corretoraDataSet.ViewTabelaFipe'. Você pode movê-la ou removê-la conforme necessário.
       //     this.viewTabelaFipeTableAdapter.Fill(this.corretoraDataSet.ViewTabelaFipe);
          //  this.viewModeloTableAdapter.Fill(this.corretoraDataSet.ViewModelo);
        }

        private void Administrador_Load(object sender, EventArgs e)
        {
        //    this.viewModeloMarcaTableAdapter.Fill(this.corretoraDataSet1.ViewModeloMarca);
            // this.viewModeloTableAdapter.Fill(this.corretoraDataSet.viewModelo);
            // this.viewModeloTableAdapter.Fill(this.corretoraDataSet.viewModelo);
            // this.marcaTableAdapter.Fill(this.corretoraDataSet.Marca);

            var marca = corretoraDataSet.Marca.NewMarcaRow();
            marca.Id = 0;
            marca.Marca = "(Todas)";
            corretoraDataSet.Marca.AddMarcaRow(marca);

           this.modeloTableAdapter.Fill(this.corretoraDataSet.Modelo);
            var modelo = corretoraDataSet.Modelo.NewModeloRow();
            modelo.ModeloId = 0;
            modelo.Modelo = "(Todos)";
            modelo.MarcaID = 0;
            corretoraDataSet.Modelo.AddModeloRow(modelo);

           /* this.viewModeloTableAdapter.Fill(this.corretoraDataSet.ViewModelo);
            var marca2 = corretoraDataSet.ViewModelo.NewViewModeloRow();
            marca2.ModeloId = 0;
            marca2.MarcaId = 0;
            marca2.Marca = "(Todas)";
            marca2.Modelo = "(Todos)";
            corretoraDataSet.ViewModelo.AddViewModeloRow(marca2);*/

            Atualiza();
            // marcaBindingSource.Sort = "Marca";
        }

        private void viewTabelaFipeBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.viewTabelaFipeBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.corretoraDataSet);
        }

        private void viewTabelaFipeBindingNavigator_RefreshItems(object sender, EventArgs e)
        {

        }
        private void tableLayoutPanel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void viewTabelaFipeBindingNavigator_RefreshItems_1(object sender, EventArgs e)
        {

        }

        private void marcasToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            new CadastrarMarcas().ShowDialog();

        }

        private void modelosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new CadastrarModelos().ShowDialog();
        }

        private void tabelaFIPEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new CadastroTabelaFIPE().ShowDialog();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {

        }


        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private void tabelaFIPEBindingNavigator_RefreshItems(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void fKApolicesMarcaBindingSource1_PositionChanged(object sender, EventArgs e)
        {

        }

        private void modeloBindingNavigator_RefreshItems(object sender, EventArgs e)
        {

        }

        private void toolStripButton8_Click(object sender, EventArgs e)
        {

        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void toolStripButton9_Click(object sender, EventArgs e)
        {

        }

        private void adicionarMarca_Click(object sender, EventArgs e)
        {
            
        }

        private void marcaDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void marcaBindingNavigator_RefreshItems(object sender, EventArgs e)
        {

        }

        private void bindingNavigatorAddNewItem_Click(object sender, EventArgs e)
        {
            var adicionar = new AddEditarMarcas();
            adicionar.ShowDialog();
            Atualiza();
        }

        private void toolStripButton20_Click(object sender, EventArgs e)
        {
            var editar = new AddEditarMarcas();
            var marca = corretoraDataSet.Marca
                [marcaBindingSource.Position];
            editar.Editar(marca.Id);
            editar.ShowDialog();
            Atualiza();
        }

        private void toolStripButton1_Click_1(object sender, EventArgs e)
        {
            var adicionarModelo = new AddEditarModelos();
            adicionarModelo.ShowDialog();
            Atualiza();
        }

        private void toolStripButton7_Click(object sender, EventArgs e)
        {
            var editar = new AddEditarModelos();
            var modelo = corretoraDataSet.Modelo
                [modeloBindingSource.Position];
            editar.EditarModelo(modelo.ModeloId);
            editar.ShowDialog();
            Atualiza();
        }

        private void bindingNavigatorDeleteItem_Click(object sender, EventArgs e)
        {
            //  var modelo = corretoraDataSet.Modelo[modeloBindingSource.Position];
            // modelo.Delete();
         //   DialogResult result = MessageBox.Show("Tem certeza que deseja excluir?", "Confirmação", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            //Atualiza();
        }

        //Adicionar e Editar  - Tabela FIPE
        private void toolStripButton14_Click(object sender, EventArgs e)
        {
            var adicionarTabelaFipe = new AddEditarTabelaFipe();
            adicionarTabelaFipe.ShowDialog();
            Atualiza();
        }


        private void toolStripButton8_Click_1(object sender, EventArgs e)
        {
            var editar = new AddEditarTabelaFipe();
            var tabelaFipe = corretoraDataSet.TabelaFIPE
                [tabelaFIPEBindingSource.Position];
            editar.EditarTabelaFipe(tabelaFipe.TabelaFipeId);
            editar.ShowDialog();
            Atualiza();
        }
       /* private void modeloBindingSource_PositionChanged(object sender, EventArgs e)
        {
            if(modeloBindingSource.Position == 0)
            {
                marcaBindingSource.RemoveFilter();
            }
            else
            {
                var desccat = comboBox3.Text;
                marcaBindingSource.Filter =
                    "Marca = '" + desccat + "'";

            }
        }*/

        private void marcaBindingSource_PositionChanged(object sender, EventArgs e)
        { 
          
             /*if (marcaBindingSource.Position == 0)
             {
                 marcaBindingSource.RemoveFilter();
             }
             else
             {
                 var desccat = comboBox1.Text;
                 modeloBindingSource.Filter =
                     "MarcaID = '" + desccat + "{marcaId}'";

             }*/
        }

        private void comboBox2_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }

        private void viewModeloBindingNavigator_RefreshItems(object sender, EventArgs e)
        {

        }

        private void viewModeloBindingSource_CurrentChanged(object sender, EventArgs e)
        {

        }

        private void viewModeloDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void viewModeloBindingSource_PositionChanged(object sender, EventArgs e)
        {
            /*if (viewModeloBindingSource.Position == 0)
            {
                marcaBindingSource.RemoveFilter();
            }
            else
            {
                var desccat = comboBox2.Text;
                marcaBindingSource.Filter =
                    "Marca = '" + desccat + "'";

            }*/
        }

        private void comboBox5_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void toolStripButton15_Click(object sender, EventArgs e)
        {

        }
    }
}
