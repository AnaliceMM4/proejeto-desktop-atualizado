﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoFinalDesktop2
{
    public partial class FormDadosComplementares : Form
    {
        public FormDadosComplementares()
        {
            InitializeComponent();
        }

        private void labelVoltar_Click(object sender, EventArgs e)
        {
            // new FormSimulacao().ShowDialog();
            this.Hide();
            FormSimulacao f = new FormSimulacao();
            f.Closed += (s, args) => this.Close();
            f.Show();

        }

        private void labelAvancar_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormCalculoApolice f = new FormCalculoApolice();
            f.Closed += (s, args) => this.Close();
            f.Show();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void FormDadosComplementares_Load(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
