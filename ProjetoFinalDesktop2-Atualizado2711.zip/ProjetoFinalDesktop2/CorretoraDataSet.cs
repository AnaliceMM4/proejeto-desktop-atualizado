﻿namespace ProjetoFinalDesktop2
{


    partial class CorretoraDataSet
    {
        partial class ApolicesDataTable
        {
        }
    }
}

namespace ProjetoFinalDesktop2.CorretoraDataSetTableAdapters {
    
    
    public partial class ApolicesTableAdapter {
    }
}
