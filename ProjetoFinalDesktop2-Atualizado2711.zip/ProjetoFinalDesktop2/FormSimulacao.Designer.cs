﻿namespace ProjetoFinalDesktop2
{
    partial class FormSimulacao
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormSimulacao));
            System.Windows.Forms.Label apoliceIdLabel;
            System.Windows.Forms.Label marcaLabel;
            System.Windows.Forms.Label modeloLabel;
            System.Windows.Forms.Label anoFabricacaoLabel;
            System.Windows.Forms.Label anoModeloLabel;
            System.Windows.Forms.Label rouboLabel;
            System.Windows.Forms.Label vidrosLabel;
            System.Windows.Forms.Label acidentesLabel;
            System.Windows.Forms.Label danosTerceirosLabel;
            System.Windows.Forms.Label franquiaRedLabel;
            this.corretoraDataSet = new ProjetoFinalDesktop2.CorretoraDataSet();
            this.apolicesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.apolicesTableAdapter = new ProjetoFinalDesktop2.CorretoraDataSetTableAdapters.ApolicesTableAdapter();
            this.tableAdapterManager = new ProjetoFinalDesktop2.CorretoraDataSetTableAdapters.TableAdapterManager();
            this.apolicesBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.apolicesBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.apoliceIdTextBox = new System.Windows.Forms.TextBox();
            this.marcaTextBox = new System.Windows.Forms.TextBox();
            this.modeloTextBox = new System.Windows.Forms.TextBox();
            this.anoFabricacaoTextBox = new System.Windows.Forms.TextBox();
            this.anoModeloTextBox = new System.Windows.Forms.TextBox();
            this.rouboCheckBox = new System.Windows.Forms.CheckBox();
            this.vidrosCheckBox = new System.Windows.Forms.CheckBox();
            this.acidentesCheckBox = new System.Windows.Forms.CheckBox();
            this.danosTerceirosCheckBox = new System.Windows.Forms.CheckBox();
            this.franquiaRedCheckBox = new System.Windows.Forms.CheckBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.labelVoltar = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.labelAvancar = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            apoliceIdLabel = new System.Windows.Forms.Label();
            marcaLabel = new System.Windows.Forms.Label();
            modeloLabel = new System.Windows.Forms.Label();
            anoFabricacaoLabel = new System.Windows.Forms.Label();
            anoModeloLabel = new System.Windows.Forms.Label();
            rouboLabel = new System.Windows.Forms.Label();
            vidrosLabel = new System.Windows.Forms.Label();
            acidentesLabel = new System.Windows.Forms.Label();
            danosTerceirosLabel = new System.Windows.Forms.Label();
            franquiaRedLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.corretoraDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.apolicesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.apolicesBindingNavigator)).BeginInit();
            this.apolicesBindingNavigator.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // corretoraDataSet
            // 
            this.corretoraDataSet.DataSetName = "CorretoraDataSet";
            this.corretoraDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // apolicesBindingSource
            // 
            this.apolicesBindingSource.DataMember = "Apolices";
            this.apolicesBindingSource.DataSource = this.corretoraDataSet;
            // 
            // apolicesTableAdapter
            // 
            this.apolicesTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.ApolicesTableAdapter = this.apolicesTableAdapter;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.ClientesTableAdapter = null;
            this.tableAdapterManager.MarcaTableAdapter = null;
            this.tableAdapterManager.ModeloTableAdapter = null;
            this.tableAdapterManager.TabelaFIPETableAdapter = null;
            this.tableAdapterManager.UpdateOrder = ProjetoFinalDesktop2.CorretoraDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // apolicesBindingNavigator
            // 
            this.apolicesBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.apolicesBindingNavigator.BindingSource = this.apolicesBindingSource;
            this.apolicesBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.apolicesBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.apolicesBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.apolicesBindingNavigatorSaveItem});
            this.apolicesBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.apolicesBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.apolicesBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.apolicesBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.apolicesBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.apolicesBindingNavigator.Name = "apolicesBindingNavigator";
            this.apolicesBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.apolicesBindingNavigator.Size = new System.Drawing.Size(884, 25);
            this.apolicesBindingNavigator.TabIndex = 0;
            this.apolicesBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Mover primeiro";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Mover anterior";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Posição";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Posição atual";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(37, 22);
            this.bindingNavigatorCountItem.Text = "de {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Número total de itens";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Mover próximo";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Mover último";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Adicionar novo";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Excluir";
            // 
            // apolicesBindingNavigatorSaveItem
            // 
            this.apolicesBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.apolicesBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("apolicesBindingNavigatorSaveItem.Image")));
            this.apolicesBindingNavigatorSaveItem.Name = "apolicesBindingNavigatorSaveItem";
            this.apolicesBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.apolicesBindingNavigatorSaveItem.Text = "Salvar Dados";
            this.apolicesBindingNavigatorSaveItem.Click += new System.EventHandler(this.apolicesBindingNavigatorSaveItem_Click_3);
            // 
            // apoliceIdLabel
            // 
            apoliceIdLabel.AutoSize = true;
            apoliceIdLabel.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            apoliceIdLabel.Location = new System.Drawing.Point(316, 20);
            apoliceIdLabel.Name = "apoliceIdLabel";
            apoliceIdLabel.Size = new System.Drawing.Size(82, 19);
            apoliceIdLabel.TabIndex = 1;
            apoliceIdLabel.Text = "Apolice Id:";
            apoliceIdLabel.Click += new System.EventHandler(this.apoliceIdLabel_Click);
            // 
            // apoliceIdTextBox
            // 
            this.apoliceIdTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.apolicesBindingSource, "ApoliceId", true));
            this.apoliceIdTextBox.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.apoliceIdTextBox.Location = new System.Drawing.Point(449, 16);
            this.apoliceIdTextBox.Name = "apoliceIdTextBox";
            this.apoliceIdTextBox.Size = new System.Drawing.Size(145, 26);
            this.apoliceIdTextBox.TabIndex = 2;
            this.apoliceIdTextBox.TextChanged += new System.EventHandler(this.apoliceIdTextBox_TextChanged);
            // 
            // marcaLabel
            // 
            marcaLabel.AutoSize = true;
            marcaLabel.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            marcaLabel.Location = new System.Drawing.Point(316, 50);
            marcaLabel.Name = "marcaLabel";
            marcaLabel.Size = new System.Drawing.Size(56, 19);
            marcaLabel.TabIndex = 3;
            marcaLabel.Text = "Marca:";
            // 
            // marcaTextBox
            // 
            this.marcaTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.apolicesBindingSource, "Marca", true));
            this.marcaTextBox.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.marcaTextBox.Location = new System.Drawing.Point(449, 48);
            this.marcaTextBox.Name = "marcaTextBox";
            this.marcaTextBox.Size = new System.Drawing.Size(145, 26);
            this.marcaTextBox.TabIndex = 4;
            this.marcaTextBox.TextChanged += new System.EventHandler(this.marcaTextBox_TextChanged);
            // 
            // modeloLabel
            // 
            modeloLabel.AutoSize = true;
            modeloLabel.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            modeloLabel.Location = new System.Drawing.Point(316, 79);
            modeloLabel.Name = "modeloLabel";
            modeloLabel.Size = new System.Drawing.Size(65, 19);
            modeloLabel.TabIndex = 5;
            modeloLabel.Text = "Modelo:";
            // 
            // modeloTextBox
            // 
            this.modeloTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.apolicesBindingSource, "Modelo", true));
            this.modeloTextBox.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.modeloTextBox.Location = new System.Drawing.Point(449, 77);
            this.modeloTextBox.Name = "modeloTextBox";
            this.modeloTextBox.Size = new System.Drawing.Size(145, 26);
            this.modeloTextBox.TabIndex = 6;
            this.modeloTextBox.TextChanged += new System.EventHandler(this.modeloTextBox_TextChanged);
            // 
            // anoFabricacaoLabel
            // 
            anoFabricacaoLabel.AutoSize = true;
            anoFabricacaoLabel.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            anoFabricacaoLabel.Location = new System.Drawing.Point(316, 110);
            anoFabricacaoLabel.Name = "anoFabricacaoLabel";
            anoFabricacaoLabel.Size = new System.Drawing.Size(120, 19);
            anoFabricacaoLabel.TabIndex = 7;
            anoFabricacaoLabel.Text = "Ano Fabricacao:";
            anoFabricacaoLabel.Click += new System.EventHandler(this.anoFabricacaoLabel_Click);
            // 
            // anoFabricacaoTextBox
            // 
            this.anoFabricacaoTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.apolicesBindingSource, "AnoFabricacao", true));
            this.anoFabricacaoTextBox.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.anoFabricacaoTextBox.Location = new System.Drawing.Point(449, 106);
            this.anoFabricacaoTextBox.Name = "anoFabricacaoTextBox";
            this.anoFabricacaoTextBox.Size = new System.Drawing.Size(145, 26);
            this.anoFabricacaoTextBox.TabIndex = 8;
            this.anoFabricacaoTextBox.TextChanged += new System.EventHandler(this.anoFabricacaoTextBox_TextChanged);
            // 
            // anoModeloLabel
            // 
            anoModeloLabel.AutoSize = true;
            anoModeloLabel.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            anoModeloLabel.Location = new System.Drawing.Point(316, 138);
            anoModeloLabel.Name = "anoModeloLabel";
            anoModeloLabel.Size = new System.Drawing.Size(97, 19);
            anoModeloLabel.TabIndex = 9;
            anoModeloLabel.Text = "Ano Modelo:";
            // 
            // anoModeloTextBox
            // 
            this.anoModeloTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.apolicesBindingSource, "AnoModelo", true));
            this.anoModeloTextBox.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.anoModeloTextBox.Location = new System.Drawing.Point(449, 134);
            this.anoModeloTextBox.Name = "anoModeloTextBox";
            this.anoModeloTextBox.Size = new System.Drawing.Size(145, 26);
            this.anoModeloTextBox.TabIndex = 10;
            this.anoModeloTextBox.TextChanged += new System.EventHandler(this.anoModeloTextBox_TextChanged);
            // 
            // rouboLabel
            // 
            rouboLabel.AutoSize = true;
            rouboLabel.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            rouboLabel.Location = new System.Drawing.Point(316, 208);
            rouboLabel.Name = "rouboLabel";
            rouboLabel.Size = new System.Drawing.Size(59, 19);
            rouboLabel.TabIndex = 17;
            rouboLabel.Text = "Roubo:";
            // 
            // rouboCheckBox
            // 
            this.rouboCheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.apolicesBindingSource, "Roubo", true));
            this.rouboCheckBox.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rouboCheckBox.Location = new System.Drawing.Point(449, 208);
            this.rouboCheckBox.Name = "rouboCheckBox";
            this.rouboCheckBox.Size = new System.Drawing.Size(145, 24);
            this.rouboCheckBox.TabIndex = 18;
            this.rouboCheckBox.Text = "checkBox1";
            this.rouboCheckBox.UseVisualStyleBackColor = true;
            // 
            // vidrosLabel
            // 
            vidrosLabel.AutoSize = true;
            vidrosLabel.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            vidrosLabel.Location = new System.Drawing.Point(316, 238);
            vidrosLabel.Name = "vidrosLabel";
            vidrosLabel.Size = new System.Drawing.Size(59, 19);
            vidrosLabel.TabIndex = 19;
            vidrosLabel.Text = "Vidros:";
            // 
            // vidrosCheckBox
            // 
            this.vidrosCheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.apolicesBindingSource, "Vidros", true));
            this.vidrosCheckBox.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vidrosCheckBox.Location = new System.Drawing.Point(449, 238);
            this.vidrosCheckBox.Name = "vidrosCheckBox";
            this.vidrosCheckBox.Size = new System.Drawing.Size(145, 24);
            this.vidrosCheckBox.TabIndex = 20;
            this.vidrosCheckBox.Text = "checkBox1";
            this.vidrosCheckBox.UseVisualStyleBackColor = true;
            // 
            // acidentesLabel
            // 
            acidentesLabel.AutoSize = true;
            acidentesLabel.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            acidentesLabel.Location = new System.Drawing.Point(316, 268);
            acidentesLabel.Name = "acidentesLabel";
            acidentesLabel.Size = new System.Drawing.Size(80, 19);
            acidentesLabel.TabIndex = 21;
            acidentesLabel.Text = "Acidentes:";
            // 
            // acidentesCheckBox
            // 
            this.acidentesCheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.apolicesBindingSource, "Acidentes", true));
            this.acidentesCheckBox.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.acidentesCheckBox.Location = new System.Drawing.Point(449, 268);
            this.acidentesCheckBox.Name = "acidentesCheckBox";
            this.acidentesCheckBox.Size = new System.Drawing.Size(145, 24);
            this.acidentesCheckBox.TabIndex = 22;
            this.acidentesCheckBox.Text = "checkBox1";
            this.acidentesCheckBox.UseVisualStyleBackColor = true;
            // 
            // danosTerceirosLabel
            // 
            danosTerceirosLabel.AutoSize = true;
            danosTerceirosLabel.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            danosTerceirosLabel.Location = new System.Drawing.Point(316, 298);
            danosTerceirosLabel.Name = "danosTerceirosLabel";
            danosTerceirosLabel.Size = new System.Drawing.Size(126, 19);
            danosTerceirosLabel.TabIndex = 23;
            danosTerceirosLabel.Text = "Danos Terceiros:";
            // 
            // danosTerceirosCheckBox
            // 
            this.danosTerceirosCheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.apolicesBindingSource, "DanosTerceiros", true));
            this.danosTerceirosCheckBox.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.danosTerceirosCheckBox.Location = new System.Drawing.Point(449, 298);
            this.danosTerceirosCheckBox.Name = "danosTerceirosCheckBox";
            this.danosTerceirosCheckBox.Size = new System.Drawing.Size(145, 24);
            this.danosTerceirosCheckBox.TabIndex = 24;
            this.danosTerceirosCheckBox.Text = "checkBox1";
            this.danosTerceirosCheckBox.UseVisualStyleBackColor = true;
            // 
            // franquiaRedLabel
            // 
            franquiaRedLabel.AutoSize = true;
            franquiaRedLabel.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            franquiaRedLabel.Location = new System.Drawing.Point(316, 323);
            franquiaRedLabel.Name = "franquiaRedLabel";
            franquiaRedLabel.Size = new System.Drawing.Size(107, 19);
            franquiaRedLabel.TabIndex = 25;
            franquiaRedLabel.Text = "Franquia Red:";
            franquiaRedLabel.Click += new System.EventHandler(this.franquiaRedLabel_Click);
            // 
            // franquiaRedCheckBox
            // 
            this.franquiaRedCheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.apolicesBindingSource, "FranquiaRed", true));
            this.franquiaRedCheckBox.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.franquiaRedCheckBox.Location = new System.Drawing.Point(448, 323);
            this.franquiaRedCheckBox.Name = "franquiaRedCheckBox";
            this.franquiaRedCheckBox.Size = new System.Drawing.Size(145, 24);
            this.franquiaRedCheckBox.TabIndex = 26;
            this.franquiaRedCheckBox.Text = "checkBox1";
            this.franquiaRedCheckBox.UseVisualStyleBackColor = true;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.labelVoltar);
            this.panel3.Controls.Add(this.label9);
            this.panel3.Controls.Add(this.labelAvancar);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel3.Location = new System.Drawing.Point(0, 452);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(884, 59);
            this.panel3.TabIndex = 27;
            // 
            // labelVoltar
            // 
            this.labelVoltar.AutoSize = true;
            this.labelVoltar.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelVoltar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelVoltar.Location = new System.Drawing.Point(541, 18);
            this.labelVoltar.Name = "labelVoltar";
            this.labelVoltar.Size = new System.Drawing.Size(53, 22);
            this.labelVoltar.TabIndex = 3;
            this.labelVoltar.Text = "Voltar";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(166, 18);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(39, 22);
            this.label9.TabIndex = 4;
            this.label9.Text = "Sair";
            // 
            // labelAvancar
            // 
            this.labelAvancar.AutoSize = true;
            this.labelAvancar.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelAvancar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAvancar.Location = new System.Drawing.Point(604, 18);
            this.labelAvancar.Name = "labelAvancar";
            this.labelAvancar.Size = new System.Drawing.Size(69, 22);
            this.labelAvancar.TabIndex = 2;
            this.labelAvancar.Text = "Avançar";
            this.labelAvancar.Click += new System.EventHandler(this.labelAvancar_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.acidentesCheckBox);
            this.panel1.Controls.Add(this.franquiaRedCheckBox);
            this.panel1.Controls.Add(franquiaRedLabel);
            this.panel1.Controls.Add(apoliceIdLabel);
            this.panel1.Controls.Add(this.danosTerceirosCheckBox);
            this.panel1.Controls.Add(this.apoliceIdTextBox);
            this.panel1.Controls.Add(danosTerceirosLabel);
            this.panel1.Controls.Add(marcaLabel);
            this.panel1.Controls.Add(acidentesLabel);
            this.panel1.Controls.Add(this.marcaTextBox);
            this.panel1.Controls.Add(this.vidrosCheckBox);
            this.panel1.Controls.Add(modeloLabel);
            this.panel1.Controls.Add(vidrosLabel);
            this.panel1.Controls.Add(this.modeloTextBox);
            this.panel1.Controls.Add(this.rouboCheckBox);
            this.panel1.Controls.Add(anoFabricacaoLabel);
            this.panel1.Controls.Add(rouboLabel);
            this.panel1.Controls.Add(this.anoFabricacaoTextBox);
            this.panel1.Controls.Add(this.anoModeloTextBox);
            this.panel1.Controls.Add(anoModeloLabel);
            this.panel1.Location = new System.Drawing.Point(0, 62);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(884, 392);
            this.panel1.TabIndex = 28;
            // 
            // FormSimulacao
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(884, 511);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.apolicesBindingNavigator);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormSimulacao";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Simulação do Carro";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FormSimulacao_Load);
            ((System.ComponentModel.ISupportInitialize)(this.corretoraDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.apolicesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.apolicesBindingNavigator)).EndInit();
            this.apolicesBindingNavigator.ResumeLayout(false);
            this.apolicesBindingNavigator.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private CorretoraDataSet corretoraDataSet;
        private System.Windows.Forms.BindingSource apolicesBindingSource;
        private CorretoraDataSetTableAdapters.ApolicesTableAdapter apolicesTableAdapter;
        private CorretoraDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator apolicesBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton apolicesBindingNavigatorSaveItem;
        private System.Windows.Forms.TextBox apoliceIdTextBox;
        private System.Windows.Forms.TextBox marcaTextBox;
        private System.Windows.Forms.TextBox modeloTextBox;
        private System.Windows.Forms.TextBox anoFabricacaoTextBox;
        private System.Windows.Forms.TextBox anoModeloTextBox;
        private System.Windows.Forms.CheckBox rouboCheckBox;
        private System.Windows.Forms.CheckBox vidrosCheckBox;
        private System.Windows.Forms.CheckBox acidentesCheckBox;
        private System.Windows.Forms.CheckBox danosTerceirosCheckBox;
        private System.Windows.Forms.CheckBox franquiaRedCheckBox;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label labelVoltar;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label labelAvancar;
        private System.Windows.Forms.Panel panel1;
    }
}