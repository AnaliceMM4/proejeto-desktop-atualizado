﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoFinalDesktop2
{
    public partial class FormCalculoApolice : Form
    {
        public FormCalculoApolice()
        {
            InitializeComponent();
        }

        private void labelTitulo_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void labelAvancar_Click(object sender, EventArgs e)
        {
            this.Hide();
            FinalizadoSimulacao f = new FinalizadoSimulacao();
            f.Closed += (s, args) => this.Close();
            f.Show();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void FormCalculoApolice_Load(object sender, EventArgs e)
        {

        }

        private void labelVoltar_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormDadosComplementares f = new FormDadosComplementares();
            f.Closed += (s, args) => this.Close();
            f.Show();
        }

        private void label7_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
