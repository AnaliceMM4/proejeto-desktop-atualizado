﻿namespace ProjetoFinalDesktop2
{


    partial class CorretoraDataSet
    {
        partial class ViewMarcaModeloDataTable
        {
        }
    }
}
