﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace ProjetoFinalDesktop2
{
    public partial class MostrarModelos : Form
    {
        public MostrarModelos()
        {
            InitializeComponent();
          
        }

        private void Atualiza()
        {
           // this.modeloTableAdapter.Fill(this.corretoraDataSet.Modelo);
            // TODO: esta linha de código carrega dados na tabela 'corretoraDataSet.Marca'. Você pode movê-la ou removê-la conforme necessário.
          //  this.marcaTableAdapter.Fill(this.corretoraDataSet.Marca);
            // TODO: esta linha de código carrega dados na tabela 'corretoraDataSet.ViewModelosMarcas'. Você pode movê-la ou removê-la conforme necessário.
            this.viewModelosMarcasTableAdapter.Fill(this.corretoraDataSet.ViewModelosMarcas);

        }

        private void MostrarModelos_Load(object sender, EventArgs e)
        {
            this.marcaTableAdapter.Fill(this.corretoraDataSet.Marca);
            var marca = corretoraDataSet.Marca.NewMarcaRow();
            marca.Id = 0;
            marca.Marca = "(Todas)";
            corretoraDataSet.Marca.AddMarcaRow(marca);

            Atualiza();
            marcaBindingSource.Sort = "Marca";

            /* var marcaModelo = corretoraDataSet.ViewModelosMarcas.NewViewModelosMarcasRow();
             marcaModelo.ModeloId = 0;
             marcaModelo.Modelo = "(Todas)";
             marcaModelo.MarcaID = 0;
             marcaModelo.Marca = "(Todas)";
             corretoraDataSet.ViewModelosMarcas.AddViewModelosMarcasRow(marcaModelo);
            */

        }

        private void viewModelosMarcasBindingSource_CurrentChanged(object sender, EventArgs e)
        {

        }

        private void viewModelosMarcasBindingSource_PositionChanged(object sender, EventArgs e)
        {
            
            
        }

        private void marcaBindingSource_PositionChanged(object sender, EventArgs e)
        {
            if (marcaBindingSource.Position == 0)
            {
                viewModelosMarcasBindingSource.RemoveFilter();
            }
            else
            {
                var desccat = comboBox1.Text;
                viewModelosMarcasBindingSource.Filter = "Marca = '" + desccat + "'";
            }
        }

        /* private void modeloBindingSource_PositionChanged(object sender, EventArgs e)
         {
             if (modeloBindingSource.Position == 0)
             {
                 viewModelosMarcasBindingSource.RemoveFilter();
             }
             else
             {
                 var desccat = comboBox1.Text;
                 viewModelosMarcasBindingSource.Filter = "Marca = '" + desccat + "'";

             }
         }*/
    }
}
