﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoFinalDesktop2
{
    public partial class MenuADM : Form
    {
        public MenuADM()
        {
            InitializeComponent();
        }

        private void Atualiza() {
            this.modeloTableAdapter.Fill(this.corretoraDataSet.Modelo);

            this.marcaTableAdapter.Fill(this.corretoraDataSet.Marca);
            this.viewModelosMarcasTableAdapter.Fill(this.corretoraDataSet.ViewModelosMarcas);

        }

        private void marcaBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.marcaBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.corretoraDataSet);

        }

        private void marcaBindingNavigatorSaveItem_Click_1(object sender, EventArgs e)
        {
            this.Validate();
            this.marcaBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.corretoraDataSet);

        }

        private void MenuADM_Load(object sender, EventArgs e)
        {
            // TODO: esta linha de código carrega dados na tabela 'corretoraDataSet.TabelaFIPE'. Você pode movê-la ou removê-la conforme necessário.
            this.tabelaFIPETableAdapter.Fill(this.corretoraDataSet.TabelaFIPE);
            // TODO: esta linha de código carrega dados na tabela 'corretoraDataSet.Modelo'. Você pode movê-la ou removê-la conforme necessário.
            // TODO: esta linha de código carrega dados na tabela 'corretoraDataSet.Modelo'. Você pode movê-la ou removê-la conforme necessário.
            // TODO: esta linha de código carrega dados na tabela 'corretoraDataSet.ViewModelosMarcas'. Você pode movê-la ou removê-la conforme necessário.
            // TODO: esta linha de código carrega dados na tabela 'corretoraDataSet.Marca'. Você pode movê-la ou removê-la conforme necessário.

            this.marcaTableAdapter.Fill(this.corretoraDataSet.Marca);
            var marca = corretoraDataSet.Marca.NewMarcaRow();
            marca.Id = 0;
            marca.Marca = "(Todas)";
            corretoraDataSet.Marca.AddMarcaRow(marca);

            Atualiza();
           // marcaBindingSource.Sort = "Marca";
        }

        //ADICIONAR E EDITAR - MARCA
        private void toolStripButton20_Click(object sender, EventArgs e)
        {
            var editar = new AddEditarMarcas();
            var marca = corretoraDataSet.Marca
                [marcaBindingSource.Position];
            editar.Editar(marca.Id);
            editar.ShowDialog();
            Atualiza();
        }

        private void bindingNavigatorAddNewItem_Click(object sender, EventArgs e)
        {
            var adicionar = new AddEditarMarcas();
            adicionar.ShowDialog();
            Atualiza();
        }

        private void toolStripButton8_Click(object sender, EventArgs e)
        {
            var editar = new AddEditarModelos();
            var modelo = corretoraDataSet.Modelo
                [modeloBindingSource.Position];
            editar.EditarModelo(modelo.ModeloId);
            editar.ShowDialog();
            Atualiza();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            var adicionarModelo = new AddEditarModelos();
            adicionarModelo.ShowDialog();
            Atualiza();

        }

        private void marcaBindingSource_PositionChanged(object sender, EventArgs e)
        {
            if (marcaBindingSource.Position == 0)
            {
                viewModelosMarcasBindingSource.RemoveFilter();
            }
            else
            {
                var desccat = comboBox1.Text;
                viewModelosMarcasBindingSource.Filter = "Marca = '" + desccat + "'";
            }
        }

        private void toolStripButton16_Click(object sender, EventArgs e)
        {
            var editar = new AddEditarTabelaFIpe();
            var tabelaFipe = corretoraDataSet.TabelaFIPE
                [tabelaFIPEBindingSource.Position];
            editar.EditarTabelaFipe(tabelaFipe.TabelaFipeId);
            editar.ShowDialog();
            Atualiza();
        }

        private void toolStripButton9_Click(object sender, EventArgs e)
        {
            var adicionarTabelaFipe = new AddEditarTabelaFIpe();
            adicionarTabelaFipe.ShowDialog();
            Atualiza();
        }
    }
}
