﻿namespace ProjetoFinalDesktop2
{
    partial class Simulacao
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label apoliceIdLabel;
            System.Windows.Forms.Label marcaLabel;
            System.Windows.Forms.Label modeloLabel;
            System.Windows.Forms.Label anoFabricacaoLabel;
            System.Windows.Forms.Label anoModeloLabel;
            System.Windows.Forms.Label valorDoBemLabel2;
            System.Windows.Forms.Label combustivelLabel2;
            System.Windows.Forms.Label chassiLabel2;
            System.Windows.Forms.Label placaLabel2;
            System.Windows.Forms.Label rouboLabel1;
            System.Windows.Forms.Label vidrosLabel1;
            System.Windows.Forms.Label acidentesLabel1;
            System.Windows.Forms.Label danosTerceirosLabel1;
            System.Windows.Forms.Label franquiaRedLabel1;
            System.Windows.Forms.Label valorFranquiaLabel2;
            System.Windows.Forms.Label valorApoliceLabel2;
            System.Windows.Forms.Label valorPremioLabel2;
            System.Windows.Forms.Label label1;
            System.Windows.Forms.Label label2;
            System.Windows.Forms.Label label3;
            System.Windows.Forms.Label label4;
            System.Windows.Forms.Label label5;
            System.Windows.Forms.Label label6;
            System.Windows.Forms.Label label11;
            System.Windows.Forms.Label label12;
            System.Windows.Forms.Label label13;
            System.Windows.Forms.Label label14;
            System.Windows.Forms.Label label15;
            System.Windows.Forms.Label label7;
            System.Windows.Forms.Label label8;
            System.Windows.Forms.Label label9;
            System.Windows.Forms.Label label10;
            System.Windows.Forms.Label categoriaMotLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Simulacao));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.apoliceIdTextBox = new System.Windows.Forms.TextBox();
            this.viewApolicesClientesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.corretoraDataSet = new ProjetoFinalDesktop2.CorretoraDataSet();
            this.marcaTextBox = new System.Windows.Forms.TextBox();
            this.modeloTextBox = new System.Windows.Forms.TextBox();
            this.anoFabricacaoTextBox = new System.Windows.Forms.TextBox();
            this.anoModeloTextBox = new System.Windows.Forms.TextBox();
            this.valorDoBemTextBox2 = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.apolicesBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.apolicesBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.combustivelTextBox2 = new System.Windows.Forms.TextBox();
            this.chassiTextBox2 = new System.Windows.Forms.TextBox();
            this.placaTextBox2 = new System.Windows.Forms.TextBox();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.bindingNavigator1 = new System.Windows.Forms.BindingNavigator(this.components);
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripTextBox1 = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton5 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton6 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton7 = new System.Windows.Forms.ToolStripButton();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.rouboCheckBox2 = new System.Windows.Forms.CheckBox();
            this.vidrosCheckBox2 = new System.Windows.Forms.CheckBox();
            this.acidentesCheckBox2 = new System.Windows.Forms.CheckBox();
            this.danosTerceirosCheckBox2 = new System.Windows.Forms.CheckBox();
            this.franquiaRedCheckBox2 = new System.Windows.Forms.CheckBox();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.bindingNavigator2 = new System.Windows.Forms.BindingNavigator(this.components);
            this.toolStripButton8 = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel2 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripButton9 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton10 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton11 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripTextBox2 = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton12 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton13 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton14 = new System.Windows.Forms.ToolStripButton();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.valorFranquiaTextBox2 = new System.Windows.Forms.TextBox();
            this.valorApoliceTextBox2 = new System.Windows.Forms.TextBox();
            this.valorPremioTextBox2 = new System.Windows.Forms.TextBox();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.bindingNavigator3 = new System.Windows.Forms.BindingNavigator(this.components);
            this.toolStripButton15 = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel3 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripButton16 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton17 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton18 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripTextBox3 = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton19 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton20 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator9 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton21 = new System.Windows.Forms.ToolStripButton();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.categoriaMotTextBox = new System.Windows.Forms.TextBox();
            this.bindingNavigator4 = new System.Windows.Forms.BindingNavigator(this.components);
            this.toolStripButton22 = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel4 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripButton23 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton24 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton25 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator10 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripTextBox4 = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripSeparator11 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton26 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton27 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator12 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton28 = new System.Windows.Forms.ToolStripButton();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.apolicesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.viewModelosMarcasBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.apolicesTableAdapter = new ProjetoFinalDesktop2.CorretoraDataSetTableAdapters.ApolicesTableAdapter();
            this.tableAdapterManager = new ProjetoFinalDesktop2.CorretoraDataSetTableAdapters.TableAdapterManager();
            this.marcaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.marcaTableAdapter = new ProjetoFinalDesktop2.CorretoraDataSetTableAdapters.MarcaTableAdapter();
            this.modeloBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.modeloTableAdapter = new ProjetoFinalDesktop2.CorretoraDataSetTableAdapters.ModeloTableAdapter();
            this.viewModelosMarcasTableAdapter = new ProjetoFinalDesktop2.CorretoraDataSetTableAdapters.ViewModelosMarcasTableAdapter();
            this.viewApolicesClientesTableAdapter = new ProjetoFinalDesktop2.CorretoraDataSetTableAdapters.ViewApolicesClientesTableAdapter();
            this.button16 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            apoliceIdLabel = new System.Windows.Forms.Label();
            marcaLabel = new System.Windows.Forms.Label();
            modeloLabel = new System.Windows.Forms.Label();
            anoFabricacaoLabel = new System.Windows.Forms.Label();
            anoModeloLabel = new System.Windows.Forms.Label();
            valorDoBemLabel2 = new System.Windows.Forms.Label();
            combustivelLabel2 = new System.Windows.Forms.Label();
            chassiLabel2 = new System.Windows.Forms.Label();
            placaLabel2 = new System.Windows.Forms.Label();
            rouboLabel1 = new System.Windows.Forms.Label();
            vidrosLabel1 = new System.Windows.Forms.Label();
            acidentesLabel1 = new System.Windows.Forms.Label();
            danosTerceirosLabel1 = new System.Windows.Forms.Label();
            franquiaRedLabel1 = new System.Windows.Forms.Label();
            valorFranquiaLabel2 = new System.Windows.Forms.Label();
            valorApoliceLabel2 = new System.Windows.Forms.Label();
            valorPremioLabel2 = new System.Windows.Forms.Label();
            label1 = new System.Windows.Forms.Label();
            label2 = new System.Windows.Forms.Label();
            label3 = new System.Windows.Forms.Label();
            label4 = new System.Windows.Forms.Label();
            label5 = new System.Windows.Forms.Label();
            label6 = new System.Windows.Forms.Label();
            label11 = new System.Windows.Forms.Label();
            label12 = new System.Windows.Forms.Label();
            label13 = new System.Windows.Forms.Label();
            label14 = new System.Windows.Forms.Label();
            label15 = new System.Windows.Forms.Label();
            label7 = new System.Windows.Forms.Label();
            label8 = new System.Windows.Forms.Label();
            label9 = new System.Windows.Forms.Label();
            label10 = new System.Windows.Forms.Label();
            categoriaMotLabel = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.viewApolicesClientesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.corretoraDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.apolicesBindingNavigator)).BeginInit();
            this.apolicesBindingNavigator.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator1)).BeginInit();
            this.bindingNavigator1.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator2)).BeginInit();
            this.bindingNavigator2.SuspendLayout();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator3)).BeginInit();
            this.bindingNavigator3.SuspendLayout();
            this.tabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator4)).BeginInit();
            this.bindingNavigator4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.apolicesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewModelosMarcasBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.marcaBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.modeloBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // apoliceIdLabel
            // 
            apoliceIdLabel.AutoSize = true;
            apoliceIdLabel.Location = new System.Drawing.Point(46, 45);
            apoliceIdLabel.Name = "apoliceIdLabel";
            apoliceIdLabel.Size = new System.Drawing.Size(75, 17);
            apoliceIdLabel.TabIndex = 38;
            apoliceIdLabel.Text = "Apolice Id:";
            // 
            // marcaLabel
            // 
            marcaLabel.AutoSize = true;
            marcaLabel.Location = new System.Drawing.Point(46, 76);
            marcaLabel.Name = "marcaLabel";
            marcaLabel.Size = new System.Drawing.Size(51, 17);
            marcaLabel.TabIndex = 40;
            marcaLabel.Text = "Marca:";
            // 
            // modeloLabel
            // 
            modeloLabel.AutoSize = true;
            modeloLabel.Location = new System.Drawing.Point(46, 107);
            modeloLabel.Name = "modeloLabel";
            modeloLabel.Size = new System.Drawing.Size(59, 17);
            modeloLabel.TabIndex = 42;
            modeloLabel.Text = "Modelo:";
            // 
            // anoFabricacaoLabel
            // 
            anoFabricacaoLabel.AutoSize = true;
            anoFabricacaoLabel.Location = new System.Drawing.Point(46, 138);
            anoFabricacaoLabel.Name = "anoFabricacaoLabel";
            anoFabricacaoLabel.Size = new System.Drawing.Size(108, 17);
            anoFabricacaoLabel.TabIndex = 44;
            anoFabricacaoLabel.Text = "Ano Fabricacao:";
            // 
            // anoModeloLabel
            // 
            anoModeloLabel.AutoSize = true;
            anoModeloLabel.Location = new System.Drawing.Point(46, 169);
            anoModeloLabel.Name = "anoModeloLabel";
            anoModeloLabel.Size = new System.Drawing.Size(87, 17);
            anoModeloLabel.TabIndex = 46;
            anoModeloLabel.Text = "Ano Modelo:";
            // 
            // valorDoBemLabel2
            // 
            valorDoBemLabel2.AutoSize = true;
            valorDoBemLabel2.Location = new System.Drawing.Point(46, 200);
            valorDoBemLabel2.Name = "valorDoBemLabel2";
            valorDoBemLabel2.Size = new System.Drawing.Size(97, 17);
            valorDoBemLabel2.TabIndex = 64;
            valorDoBemLabel2.Text = "Valor Do Bem:";
            // 
            // combustivelLabel2
            // 
            combustivelLabel2.AutoSize = true;
            combustivelLabel2.Location = new System.Drawing.Point(85, 86);
            combustivelLabel2.Name = "combustivelLabel2";
            combustivelLabel2.Size = new System.Drawing.Size(90, 17);
            combustivelLabel2.TabIndex = 54;
            combustivelLabel2.Text = "Combustivel:";
            // 
            // chassiLabel2
            // 
            chassiLabel2.AutoSize = true;
            chassiLabel2.Location = new System.Drawing.Point(85, 117);
            chassiLabel2.Name = "chassiLabel2";
            chassiLabel2.Size = new System.Drawing.Size(51, 17);
            chassiLabel2.TabIndex = 56;
            chassiLabel2.Text = "Chassi:";
            // 
            // placaLabel2
            // 
            placaLabel2.AutoSize = true;
            placaLabel2.Location = new System.Drawing.Point(85, 148);
            placaLabel2.Name = "placaLabel2";
            placaLabel2.Size = new System.Drawing.Size(46, 17);
            placaLabel2.TabIndex = 58;
            placaLabel2.Text = "Placa:";
            // 
            // rouboLabel1
            // 
            rouboLabel1.AutoSize = true;
            rouboLabel1.Location = new System.Drawing.Point(89, 76);
            rouboLabel1.Name = "rouboLabel1";
            rouboLabel1.Size = new System.Drawing.Size(53, 17);
            rouboLabel1.TabIndex = 64;
            rouboLabel1.Text = "Roubo:";
            // 
            // vidrosLabel1
            // 
            vidrosLabel1.AutoSize = true;
            vidrosLabel1.Location = new System.Drawing.Point(89, 106);
            vidrosLabel1.Name = "vidrosLabel1";
            vidrosLabel1.Size = new System.Drawing.Size(53, 17);
            vidrosLabel1.TabIndex = 66;
            vidrosLabel1.Text = "Vidros:";
            // 
            // acidentesLabel1
            // 
            acidentesLabel1.AutoSize = true;
            acidentesLabel1.Location = new System.Drawing.Point(89, 136);
            acidentesLabel1.Name = "acidentesLabel1";
            acidentesLabel1.Size = new System.Drawing.Size(73, 17);
            acidentesLabel1.TabIndex = 68;
            acidentesLabel1.Text = "Acidentes:";
            // 
            // danosTerceirosLabel1
            // 
            danosTerceirosLabel1.AutoSize = true;
            danosTerceirosLabel1.Location = new System.Drawing.Point(89, 166);
            danosTerceirosLabel1.Name = "danosTerceirosLabel1";
            danosTerceirosLabel1.Size = new System.Drawing.Size(113, 17);
            danosTerceirosLabel1.TabIndex = 70;
            danosTerceirosLabel1.Text = "Danos Terceiros:";
            // 
            // franquiaRedLabel1
            // 
            franquiaRedLabel1.AutoSize = true;
            franquiaRedLabel1.Location = new System.Drawing.Point(89, 196);
            franquiaRedLabel1.Name = "franquiaRedLabel1";
            franquiaRedLabel1.Size = new System.Drawing.Size(95, 17);
            franquiaRedLabel1.TabIndex = 72;
            franquiaRedLabel1.Text = "Franquia Red:";
            // 
            // valorFranquiaLabel2
            // 
            valorFranquiaLabel2.AutoSize = true;
            valorFranquiaLabel2.Location = new System.Drawing.Point(73, 74);
            valorFranquiaLabel2.Name = "valorFranquiaLabel2";
            valorFranquiaLabel2.Size = new System.Drawing.Size(104, 17);
            valorFranquiaLabel2.TabIndex = 72;
            valorFranquiaLabel2.Text = "Valor Franquia:";
            // 
            // valorApoliceLabel2
            // 
            valorApoliceLabel2.AutoSize = true;
            valorApoliceLabel2.Location = new System.Drawing.Point(73, 105);
            valorApoliceLabel2.Name = "valorApoliceLabel2";
            valorApoliceLabel2.Size = new System.Drawing.Size(95, 17);
            valorApoliceLabel2.TabIndex = 74;
            valorApoliceLabel2.Text = "Valor Apolice:";
            // 
            // valorPremioLabel2
            // 
            valorPremioLabel2.AutoSize = true;
            valorPremioLabel2.Location = new System.Drawing.Point(73, 136);
            valorPremioLabel2.Name = "valorPremioLabel2";
            valorPremioLabel2.Size = new System.Drawing.Size(94, 17);
            valorPremioLabel2.TabIndex = 76;
            valorPremioLabel2.Text = "Valor Premio:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new System.Drawing.Point(59, 48);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(71, 17);
            label1.TabIndex = 102;
            label1.Text = "Cliente Id:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new System.Drawing.Point(59, 91);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(49, 17);
            label2.TabIndex = 104;
            label2.Text = "Nome:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new System.Drawing.Point(59, 122);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(72, 17);
            label3.TabIndex = 106;
            label3.Text = "Endereco:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new System.Drawing.Point(59, 153);
            label4.Name = "label4";
            label4.Size = new System.Drawing.Size(38, 17);
            label4.TabIndex = 108;
            label4.Text = "CEP:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new System.Drawing.Point(59, 184);
            label5.Name = "label5";
            label5.Size = new System.Drawing.Size(54, 17);
            label5.TabIndex = 110;
            label5.Text = "Cidade:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new System.Drawing.Point(59, 215);
            label6.Name = "label6";
            label6.Size = new System.Drawing.Size(30, 17);
            label6.TabIndex = 112;
            label6.Text = "UF:";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new System.Drawing.Point(412, 110);
            label11.Name = "label11";
            label11.Size = new System.Drawing.Size(104, 17);
            label11.TabIndex = 122;
            label11.Text = "Orgao Emissor:";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new System.Drawing.Point(59, 295);
            label12.Name = "label12";
            label12.Size = new System.Drawing.Size(102, 17);
            label12.TabIndex = 124;
            label12.Text = "Cart Motorista:";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new System.Drawing.Point(59, 327);
            label13.Name = "label13";
            label13.Size = new System.Drawing.Size(121, 17);
            label13.TabIndex = 126;
            label13.Text = "Emissao Cart Mot:";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new System.Drawing.Point(412, 296);
            label14.Name = "label14";
            label14.Size = new System.Drawing.Size(118, 17);
            label14.TabIndex = 128;
            label14.Text = "Data Nascimento:";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Location = new System.Drawing.Point(412, 326);
            label15.Name = "label15";
            label15.Size = new System.Drawing.Size(48, 17);
            label15.TabIndex = 130;
            label15.Text = "Email:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new System.Drawing.Point(412, 148);
            label7.Name = "label7";
            label7.Size = new System.Drawing.Size(66, 17);
            label7.TabIndex = 132;
            label7.Text = "Telefone:";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new System.Drawing.Point(412, 179);
            label8.Name = "label8";
            label8.Size = new System.Drawing.Size(56, 17);
            label8.TabIndex = 134;
            label8.Text = "Celular:";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new System.Drawing.Point(412, 45);
            label9.Name = "label9";
            label9.Size = new System.Drawing.Size(37, 17);
            label9.TabIndex = 136;
            label9.Text = "CPF:";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new System.Drawing.Point(412, 76);
            label10.Name = "label10";
            label10.Size = new System.Drawing.Size(30, 17);
            label10.TabIndex = 138;
            label10.Text = "RG:";
            // 
            // categoriaMotLabel
            // 
            categoriaMotLabel.AutoSize = true;
            categoriaMotLabel.Location = new System.Drawing.Point(56, 359);
            categoriaMotLabel.Name = "categoriaMotLabel";
            categoriaMotLabel.Size = new System.Drawing.Size(131, 17);
            categoriaMotLabel.TabIndex = 140;
            categoriaMotLabel.Text = "Categoria Motorista";
            categoriaMotLabel.Click += new System.EventHandler(this.categoriaMotLabel_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Font = new System.Drawing.Font("Cambria", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(4, 1);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(800, 479);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.AutoScroll = true;
            this.tabPage1.Controls.Add(this.button16);
            this.tabPage1.Controls.Add(this.button17);
            this.tabPage1.Controls.Add(this.button18);
            this.tabPage1.Controls.Add(apoliceIdLabel);
            this.tabPage1.Controls.Add(this.apoliceIdTextBox);
            this.tabPage1.Controls.Add(marcaLabel);
            this.tabPage1.Controls.Add(this.marcaTextBox);
            this.tabPage1.Controls.Add(modeloLabel);
            this.tabPage1.Controls.Add(this.modeloTextBox);
            this.tabPage1.Controls.Add(anoFabricacaoLabel);
            this.tabPage1.Controls.Add(this.anoFabricacaoTextBox);
            this.tabPage1.Controls.Add(anoModeloLabel);
            this.tabPage1.Controls.Add(this.anoModeloTextBox);
            this.tabPage1.Controls.Add(valorDoBemLabel2);
            this.tabPage1.Controls.Add(this.valorDoBemTextBox2);
            this.tabPage1.Controls.Add(this.button3);
            this.tabPage1.Controls.Add(this.button2);
            this.tabPage1.Controls.Add(this.button1);
            this.tabPage1.Controls.Add(this.apolicesBindingNavigator);
            this.tabPage1.Location = new System.Drawing.Point(4, 26);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(792, 449);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Dados do Veículo";
            this.tabPage1.UseVisualStyleBackColor = true;
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // apoliceIdTextBox
            // 
            this.apoliceIdTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewApolicesClientesBindingSource, "ApoliceId", true));
            this.apoliceIdTextBox.Location = new System.Drawing.Point(173, 42);
            this.apoliceIdTextBox.Name = "apoliceIdTextBox";
            this.apoliceIdTextBox.Size = new System.Drawing.Size(200, 25);
            this.apoliceIdTextBox.TabIndex = 39;
            // 
            // viewApolicesClientesBindingSource
            // 
            this.viewApolicesClientesBindingSource.DataMember = "ViewApolicesClientes";
            this.viewApolicesClientesBindingSource.DataSource = this.corretoraDataSet;
            // 
            // corretoraDataSet
            // 
            this.corretoraDataSet.DataSetName = "CorretoraDataSet";
            this.corretoraDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // marcaTextBox
            // 
            this.marcaTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewApolicesClientesBindingSource, "Marca", true));
            this.marcaTextBox.Location = new System.Drawing.Point(173, 73);
            this.marcaTextBox.Name = "marcaTextBox";
            this.marcaTextBox.Size = new System.Drawing.Size(200, 25);
            this.marcaTextBox.TabIndex = 41;
            // 
            // modeloTextBox
            // 
            this.modeloTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewApolicesClientesBindingSource, "Modelo", true));
            this.modeloTextBox.Location = new System.Drawing.Point(173, 104);
            this.modeloTextBox.Name = "modeloTextBox";
            this.modeloTextBox.Size = new System.Drawing.Size(200, 25);
            this.modeloTextBox.TabIndex = 43;
            // 
            // anoFabricacaoTextBox
            // 
            this.anoFabricacaoTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewApolicesClientesBindingSource, "AnoFabricacao", true));
            this.anoFabricacaoTextBox.Location = new System.Drawing.Point(173, 135);
            this.anoFabricacaoTextBox.Name = "anoFabricacaoTextBox";
            this.anoFabricacaoTextBox.Size = new System.Drawing.Size(200, 25);
            this.anoFabricacaoTextBox.TabIndex = 45;
            // 
            // anoModeloTextBox
            // 
            this.anoModeloTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewApolicesClientesBindingSource, "AnoModelo", true));
            this.anoModeloTextBox.Location = new System.Drawing.Point(173, 166);
            this.anoModeloTextBox.Name = "anoModeloTextBox";
            this.anoModeloTextBox.Size = new System.Drawing.Size(200, 25);
            this.anoModeloTextBox.TabIndex = 47;
            // 
            // valorDoBemTextBox2
            // 
            this.valorDoBemTextBox2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewApolicesClientesBindingSource, "ValorDoBem", true));
            this.valorDoBemTextBox2.Location = new System.Drawing.Point(173, 197);
            this.valorDoBemTextBox2.Name = "valorDoBemTextBox2";
            this.valorDoBemTextBox2.Size = new System.Drawing.Size(200, 25);
            this.valorDoBemTextBox2.TabIndex = 65;
            // 
            // button3
            // 
            this.button3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button3.BackColor = System.Drawing.Color.LightGray;
            this.button3.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(549, 942);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(100, 25);
            this.button3.TabIndex = 38;
            this.button3.Text = "Avançar";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button2.BackColor = System.Drawing.Color.LightGray;
            this.button2.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(442, 942);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(100, 25);
            this.button2.TabIndex = 37;
            this.button2.Text = "Voltar";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // button1
            // 
            this.button1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button1.BackColor = System.Drawing.Color.LightGray;
            this.button1.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(24, 942);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 25);
            this.button1.TabIndex = 36;
            this.button1.Text = "Sair";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // apolicesBindingNavigator
            // 
            this.apolicesBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.apolicesBindingNavigator.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.apolicesBindingNavigator.BindingSource = this.viewApolicesClientesBindingSource;
            this.apolicesBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.apolicesBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.apolicesBindingNavigator.Dock = System.Windows.Forms.DockStyle.None;
            this.apolicesBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.apolicesBindingNavigatorSaveItem});
            this.apolicesBindingNavigator.Location = new System.Drawing.Point(3, 3);
            this.apolicesBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.apolicesBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.apolicesBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.apolicesBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.apolicesBindingNavigator.Name = "apolicesBindingNavigator";
            this.apolicesBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.apolicesBindingNavigator.Size = new System.Drawing.Size(280, 25);
            this.apolicesBindingNavigator.TabIndex = 1;
            this.apolicesBindingNavigator.Text = "bindingNavigator1";
            this.apolicesBindingNavigator.RefreshItems += new System.EventHandler(this.apolicesBindingNavigator_RefreshItems);
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Adicionar novo";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(37, 17);
            this.bindingNavigatorCountItem.Text = "de {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Número total de itens";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorDeleteItem.Text = "Excluir";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 17);
            this.bindingNavigatorMoveFirstItem.Text = "Mover primeiro";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 17);
            this.bindingNavigatorMovePreviousItem.Text = "Mover anterior";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 20);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Posição";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Posição atual";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 20);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 17);
            this.bindingNavigatorMoveNextItem.Text = "Mover próximo";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 17);
            this.bindingNavigatorMoveLastItem.Text = "Mover último";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 20);
            // 
            // apolicesBindingNavigatorSaveItem
            // 
            this.apolicesBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.apolicesBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("apolicesBindingNavigatorSaveItem.Image")));
            this.apolicesBindingNavigatorSaveItem.Name = "apolicesBindingNavigatorSaveItem";
            this.apolicesBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 20);
            this.apolicesBindingNavigatorSaveItem.Text = "Salvar Dados";
            this.apolicesBindingNavigatorSaveItem.Click += new System.EventHandler(this.apolicesBindingNavigatorSaveItem_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(combustivelLabel2);
            this.tabPage2.Controls.Add(this.combustivelTextBox2);
            this.tabPage2.Controls.Add(chassiLabel2);
            this.tabPage2.Controls.Add(this.chassiTextBox2);
            this.tabPage2.Controls.Add(placaLabel2);
            this.tabPage2.Controls.Add(this.placaTextBox2);
            this.tabPage2.Controls.Add(this.button4);
            this.tabPage2.Controls.Add(this.button5);
            this.tabPage2.Controls.Add(this.button6);
            this.tabPage2.Controls.Add(this.bindingNavigator1);
            this.tabPage2.Location = new System.Drawing.Point(4, 26);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(792, 403);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Dados Complementares";
            this.tabPage2.UseVisualStyleBackColor = true;
            this.tabPage2.Click += new System.EventHandler(this.tabPage2_Click);
            // 
            // combustivelTextBox2
            // 
            this.combustivelTextBox2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewApolicesClientesBindingSource, "Combustivel", true));
            this.combustivelTextBox2.Location = new System.Drawing.Point(212, 83);
            this.combustivelTextBox2.Name = "combustivelTextBox2";
            this.combustivelTextBox2.Size = new System.Drawing.Size(200, 25);
            this.combustivelTextBox2.TabIndex = 55;
            // 
            // chassiTextBox2
            // 
            this.chassiTextBox2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewApolicesClientesBindingSource, "Chassi", true));
            this.chassiTextBox2.Location = new System.Drawing.Point(212, 114);
            this.chassiTextBox2.Name = "chassiTextBox2";
            this.chassiTextBox2.Size = new System.Drawing.Size(200, 25);
            this.chassiTextBox2.TabIndex = 57;
            // 
            // placaTextBox2
            // 
            this.placaTextBox2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewApolicesClientesBindingSource, "Placa", true));
            this.placaTextBox2.Location = new System.Drawing.Point(212, 145);
            this.placaTextBox2.Name = "placaTextBox2";
            this.placaTextBox2.Size = new System.Drawing.Size(200, 25);
            this.placaTextBox2.TabIndex = 59;
            // 
            // button4
            // 
            this.button4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button4.BackColor = System.Drawing.Color.LightGray;
            this.button4.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(588, 306);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(100, 25);
            this.button4.TabIndex = 41;
            this.button4.Text = "Avançar";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button5.BackColor = System.Drawing.Color.LightGray;
            this.button5.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.Location = new System.Drawing.Point(481, 306);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(100, 25);
            this.button5.TabIndex = 40;
            this.button5.Text = "Voltar";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button6.BackColor = System.Drawing.Color.LightGray;
            this.button6.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.Location = new System.Drawing.Point(71, 306);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(100, 25);
            this.button6.TabIndex = 39;
            this.button6.Text = "Sair";
            this.button6.UseVisualStyleBackColor = false;
            // 
            // bindingNavigator1
            // 
            this.bindingNavigator1.AddNewItem = this.toolStripButton1;
            this.bindingNavigator1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.bindingNavigator1.BindingSource = this.viewApolicesClientesBindingSource;
            this.bindingNavigator1.CountItem = this.toolStripLabel1;
            this.bindingNavigator1.DeleteItem = this.toolStripButton2;
            this.bindingNavigator1.Dock = System.Windows.Forms.DockStyle.None;
            this.bindingNavigator1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton3,
            this.toolStripButton4,
            this.toolStripSeparator1,
            this.toolStripTextBox1,
            this.toolStripLabel1,
            this.toolStripSeparator2,
            this.toolStripButton5,
            this.toolStripButton6,
            this.toolStripSeparator3,
            this.toolStripButton1,
            this.toolStripButton2,
            this.toolStripButton7});
            this.bindingNavigator1.Location = new System.Drawing.Point(3, 3);
            this.bindingNavigator1.MoveFirstItem = this.toolStripButton3;
            this.bindingNavigator1.MoveLastItem = this.toolStripButton6;
            this.bindingNavigator1.MoveNextItem = this.toolStripButton5;
            this.bindingNavigator1.MovePreviousItem = this.toolStripButton4;
            this.bindingNavigator1.Name = "bindingNavigator1";
            this.bindingNavigator1.PositionItem = this.toolStripTextBox1;
            this.bindingNavigator1.Size = new System.Drawing.Size(278, 25);
            this.bindingNavigator1.TabIndex = 2;
            this.bindingNavigator1.Text = "bindingNavigator1";
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.RightToLeftAutoMirrorImage = true;
            this.toolStripButton1.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton1.Text = "Adicionar novo";
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(37, 22);
            this.toolStripLabel1.Text = "de {0}";
            this.toolStripLabel1.ToolTipText = "Número total de itens";
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.RightToLeftAutoMirrorImage = true;
            this.toolStripButton2.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton2.Text = "Excluir";
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton3.Image")));
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.RightToLeftAutoMirrorImage = true;
            this.toolStripButton3.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton3.Text = "Mover primeiro";
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton4.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton4.Image")));
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.RightToLeftAutoMirrorImage = true;
            this.toolStripButton4.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton4.Text = "Mover anterior";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripTextBox1
            // 
            this.toolStripTextBox1.AccessibleName = "Posição";
            this.toolStripTextBox1.AutoSize = false;
            this.toolStripTextBox1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.toolStripTextBox1.Name = "toolStripTextBox1";
            this.toolStripTextBox1.Size = new System.Drawing.Size(50, 23);
            this.toolStripTextBox1.Text = "0";
            this.toolStripTextBox1.ToolTipText = "Posição atual";
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton5
            // 
            this.toolStripButton5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton5.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton5.Image")));
            this.toolStripButton5.Name = "toolStripButton5";
            this.toolStripButton5.RightToLeftAutoMirrorImage = true;
            this.toolStripButton5.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton5.Text = "Mover próximo";
            // 
            // toolStripButton6
            // 
            this.toolStripButton6.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton6.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton6.Image")));
            this.toolStripButton6.Name = "toolStripButton6";
            this.toolStripButton6.RightToLeftAutoMirrorImage = true;
            this.toolStripButton6.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton6.Text = "Mover último";
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton7
            // 
            this.toolStripButton7.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton7.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton7.Image")));
            this.toolStripButton7.Name = "toolStripButton7";
            this.toolStripButton7.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton7.Text = "Salvar Dados";
            this.toolStripButton7.Click += new System.EventHandler(this.toolStripButton7_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(rouboLabel1);
            this.tabPage3.Controls.Add(this.rouboCheckBox2);
            this.tabPage3.Controls.Add(vidrosLabel1);
            this.tabPage3.Controls.Add(this.vidrosCheckBox2);
            this.tabPage3.Controls.Add(acidentesLabel1);
            this.tabPage3.Controls.Add(this.acidentesCheckBox2);
            this.tabPage3.Controls.Add(danosTerceirosLabel1);
            this.tabPage3.Controls.Add(this.danosTerceirosCheckBox2);
            this.tabPage3.Controls.Add(franquiaRedLabel1);
            this.tabPage3.Controls.Add(this.franquiaRedCheckBox2);
            this.tabPage3.Controls.Add(this.button7);
            this.tabPage3.Controls.Add(this.button8);
            this.tabPage3.Controls.Add(this.button9);
            this.tabPage3.Controls.Add(this.bindingNavigator2);
            this.tabPage3.Location = new System.Drawing.Point(4, 26);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(792, 403);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Coberturas Desejadas";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // rouboCheckBox2
            // 
            this.rouboCheckBox2.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.viewApolicesClientesBindingSource, "Roubo", true));
            this.rouboCheckBox2.Location = new System.Drawing.Point(216, 71);
            this.rouboCheckBox2.Name = "rouboCheckBox2";
            this.rouboCheckBox2.Size = new System.Drawing.Size(200, 24);
            this.rouboCheckBox2.TabIndex = 65;
            this.rouboCheckBox2.Text = "checkBox1";
            this.rouboCheckBox2.UseVisualStyleBackColor = true;
            // 
            // vidrosCheckBox2
            // 
            this.vidrosCheckBox2.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.viewApolicesClientesBindingSource, "Vidros", true));
            this.vidrosCheckBox2.Location = new System.Drawing.Point(216, 101);
            this.vidrosCheckBox2.Name = "vidrosCheckBox2";
            this.vidrosCheckBox2.Size = new System.Drawing.Size(200, 24);
            this.vidrosCheckBox2.TabIndex = 67;
            this.vidrosCheckBox2.Text = "checkBox1";
            this.vidrosCheckBox2.UseVisualStyleBackColor = true;
            // 
            // acidentesCheckBox2
            // 
            this.acidentesCheckBox2.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.viewApolicesClientesBindingSource, "Acidentes", true));
            this.acidentesCheckBox2.Location = new System.Drawing.Point(216, 131);
            this.acidentesCheckBox2.Name = "acidentesCheckBox2";
            this.acidentesCheckBox2.Size = new System.Drawing.Size(200, 24);
            this.acidentesCheckBox2.TabIndex = 69;
            this.acidentesCheckBox2.Text = "checkBox1";
            this.acidentesCheckBox2.UseVisualStyleBackColor = true;
            // 
            // danosTerceirosCheckBox2
            // 
            this.danosTerceirosCheckBox2.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.viewApolicesClientesBindingSource, "DanosTerceiros", true));
            this.danosTerceirosCheckBox2.Location = new System.Drawing.Point(216, 161);
            this.danosTerceirosCheckBox2.Name = "danosTerceirosCheckBox2";
            this.danosTerceirosCheckBox2.Size = new System.Drawing.Size(200, 24);
            this.danosTerceirosCheckBox2.TabIndex = 71;
            this.danosTerceirosCheckBox2.Text = "checkBox1";
            this.danosTerceirosCheckBox2.UseVisualStyleBackColor = true;
            // 
            // franquiaRedCheckBox2
            // 
            this.franquiaRedCheckBox2.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.viewApolicesClientesBindingSource, "FranquiaRed", true));
            this.franquiaRedCheckBox2.Location = new System.Drawing.Point(216, 191);
            this.franquiaRedCheckBox2.Name = "franquiaRedCheckBox2";
            this.franquiaRedCheckBox2.Size = new System.Drawing.Size(200, 24);
            this.franquiaRedCheckBox2.TabIndex = 73;
            this.franquiaRedCheckBox2.Text = "checkBox1";
            this.franquiaRedCheckBox2.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            this.button7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button7.BackColor = System.Drawing.Color.LightGray;
            this.button7.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.Location = new System.Drawing.Point(589, 324);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(100, 25);
            this.button7.TabIndex = 41;
            this.button7.Text = "Avançar";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button8.BackColor = System.Drawing.Color.LightGray;
            this.button8.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.Location = new System.Drawing.Point(482, 324);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(100, 25);
            this.button8.TabIndex = 40;
            this.button8.Text = "Voltar";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button9
            // 
            this.button9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button9.BackColor = System.Drawing.Color.LightGray;
            this.button9.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.Location = new System.Drawing.Point(72, 324);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(100, 25);
            this.button9.TabIndex = 39;
            this.button9.Text = "Sair";
            this.button9.UseVisualStyleBackColor = false;
            // 
            // bindingNavigator2
            // 
            this.bindingNavigator2.AddNewItem = this.toolStripButton8;
            this.bindingNavigator2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.bindingNavigator2.BindingSource = this.viewApolicesClientesBindingSource;
            this.bindingNavigator2.CountItem = this.toolStripLabel2;
            this.bindingNavigator2.DeleteItem = this.toolStripButton9;
            this.bindingNavigator2.Dock = System.Windows.Forms.DockStyle.None;
            this.bindingNavigator2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton10,
            this.toolStripButton11,
            this.toolStripSeparator4,
            this.toolStripTextBox2,
            this.toolStripLabel2,
            this.toolStripSeparator5,
            this.toolStripButton12,
            this.toolStripButton13,
            this.toolStripSeparator6,
            this.toolStripButton8,
            this.toolStripButton9,
            this.toolStripButton14});
            this.bindingNavigator2.Location = new System.Drawing.Point(1, 0);
            this.bindingNavigator2.MoveFirstItem = this.toolStripButton10;
            this.bindingNavigator2.MoveLastItem = this.toolStripButton13;
            this.bindingNavigator2.MoveNextItem = this.toolStripButton12;
            this.bindingNavigator2.MovePreviousItem = this.toolStripButton11;
            this.bindingNavigator2.Name = "bindingNavigator2";
            this.bindingNavigator2.PositionItem = this.toolStripTextBox2;
            this.bindingNavigator2.Size = new System.Drawing.Size(278, 25);
            this.bindingNavigator2.TabIndex = 3;
            this.bindingNavigator2.Text = "c";
            // 
            // toolStripButton8
            // 
            this.toolStripButton8.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton8.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton8.Image")));
            this.toolStripButton8.Name = "toolStripButton8";
            this.toolStripButton8.RightToLeftAutoMirrorImage = true;
            this.toolStripButton8.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton8.Text = "Adicionar novo";
            // 
            // toolStripLabel2
            // 
            this.toolStripLabel2.Name = "toolStripLabel2";
            this.toolStripLabel2.Size = new System.Drawing.Size(37, 22);
            this.toolStripLabel2.Text = "de {0}";
            this.toolStripLabel2.ToolTipText = "Número total de itens";
            // 
            // toolStripButton9
            // 
            this.toolStripButton9.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton9.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton9.Image")));
            this.toolStripButton9.Name = "toolStripButton9";
            this.toolStripButton9.RightToLeftAutoMirrorImage = true;
            this.toolStripButton9.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton9.Text = "Excluir";
            // 
            // toolStripButton10
            // 
            this.toolStripButton10.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton10.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton10.Image")));
            this.toolStripButton10.Name = "toolStripButton10";
            this.toolStripButton10.RightToLeftAutoMirrorImage = true;
            this.toolStripButton10.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton10.Text = "Mover primeiro";
            // 
            // toolStripButton11
            // 
            this.toolStripButton11.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton11.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton11.Image")));
            this.toolStripButton11.Name = "toolStripButton11";
            this.toolStripButton11.RightToLeftAutoMirrorImage = true;
            this.toolStripButton11.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton11.Text = "Mover anterior";
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripTextBox2
            // 
            this.toolStripTextBox2.AccessibleName = "Posição";
            this.toolStripTextBox2.AutoSize = false;
            this.toolStripTextBox2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.toolStripTextBox2.Name = "toolStripTextBox2";
            this.toolStripTextBox2.Size = new System.Drawing.Size(50, 23);
            this.toolStripTextBox2.Text = "0";
            this.toolStripTextBox2.ToolTipText = "Posição atual";
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton12
            // 
            this.toolStripButton12.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton12.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton12.Image")));
            this.toolStripButton12.Name = "toolStripButton12";
            this.toolStripButton12.RightToLeftAutoMirrorImage = true;
            this.toolStripButton12.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton12.Text = "Mover próximo";
            // 
            // toolStripButton13
            // 
            this.toolStripButton13.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton13.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton13.Image")));
            this.toolStripButton13.Name = "toolStripButton13";
            this.toolStripButton13.RightToLeftAutoMirrorImage = true;
            this.toolStripButton13.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton13.Text = "Mover último";
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton14
            // 
            this.toolStripButton14.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton14.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton14.Image")));
            this.toolStripButton14.Name = "toolStripButton14";
            this.toolStripButton14.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton14.Text = "Salvar Dados";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(valorFranquiaLabel2);
            this.tabPage4.Controls.Add(this.valorFranquiaTextBox2);
            this.tabPage4.Controls.Add(valorApoliceLabel2);
            this.tabPage4.Controls.Add(this.valorApoliceTextBox2);
            this.tabPage4.Controls.Add(valorPremioLabel2);
            this.tabPage4.Controls.Add(this.valorPremioTextBox2);
            this.tabPage4.Controls.Add(this.button10);
            this.tabPage4.Controls.Add(this.button11);
            this.tabPage4.Controls.Add(this.button12);
            this.tabPage4.Controls.Add(this.bindingNavigator3);
            this.tabPage4.Location = new System.Drawing.Point(4, 26);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(792, 449);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Cálculo da Apólice";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // valorFranquiaTextBox2
            // 
            this.valorFranquiaTextBox2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewApolicesClientesBindingSource, "ValorFranquia", true));
            this.valorFranquiaTextBox2.Location = new System.Drawing.Point(200, 71);
            this.valorFranquiaTextBox2.Name = "valorFranquiaTextBox2";
            this.valorFranquiaTextBox2.Size = new System.Drawing.Size(200, 25);
            this.valorFranquiaTextBox2.TabIndex = 73;
            // 
            // valorApoliceTextBox2
            // 
            this.valorApoliceTextBox2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewApolicesClientesBindingSource, "ValorApolice", true));
            this.valorApoliceTextBox2.Location = new System.Drawing.Point(200, 102);
            this.valorApoliceTextBox2.Name = "valorApoliceTextBox2";
            this.valorApoliceTextBox2.Size = new System.Drawing.Size(200, 25);
            this.valorApoliceTextBox2.TabIndex = 75;
            // 
            // valorPremioTextBox2
            // 
            this.valorPremioTextBox2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewApolicesClientesBindingSource, "ValorPremio", true));
            this.valorPremioTextBox2.Location = new System.Drawing.Point(200, 133);
            this.valorPremioTextBox2.Name = "valorPremioTextBox2";
            this.valorPremioTextBox2.Size = new System.Drawing.Size(200, 25);
            this.valorPremioTextBox2.TabIndex = 77;
            // 
            // button10
            // 
            this.button10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button10.BackColor = System.Drawing.Color.LightGray;
            this.button10.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button10.Location = new System.Drawing.Point(586, 236);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(100, 25);
            this.button10.TabIndex = 41;
            this.button10.Text = "Contratar";
            this.button10.UseVisualStyleBackColor = false;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button11
            // 
            this.button11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button11.BackColor = System.Drawing.Color.LightGray;
            this.button11.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button11.Location = new System.Drawing.Point(479, 236);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(100, 25);
            this.button11.TabIndex = 40;
            this.button11.Text = "Voltar";
            this.button11.UseVisualStyleBackColor = false;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button12
            // 
            this.button12.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button12.BackColor = System.Drawing.Color.LightGray;
            this.button12.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button12.Location = new System.Drawing.Point(69, 236);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(100, 25);
            this.button12.TabIndex = 39;
            this.button12.Text = "Sair";
            this.button12.UseVisualStyleBackColor = false;
            // 
            // bindingNavigator3
            // 
            this.bindingNavigator3.AddNewItem = this.toolStripButton15;
            this.bindingNavigator3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.bindingNavigator3.BindingSource = this.viewApolicesClientesBindingSource;
            this.bindingNavigator3.CountItem = this.toolStripLabel3;
            this.bindingNavigator3.DeleteItem = this.toolStripButton16;
            this.bindingNavigator3.Dock = System.Windows.Forms.DockStyle.None;
            this.bindingNavigator3.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton17,
            this.toolStripButton18,
            this.toolStripSeparator7,
            this.toolStripTextBox3,
            this.toolStripLabel3,
            this.toolStripSeparator8,
            this.toolStripButton19,
            this.toolStripButton20,
            this.toolStripSeparator9,
            this.toolStripButton15,
            this.toolStripButton16,
            this.toolStripButton21});
            this.bindingNavigator3.Location = new System.Drawing.Point(1, 0);
            this.bindingNavigator3.MoveFirstItem = this.toolStripButton17;
            this.bindingNavigator3.MoveLastItem = this.toolStripButton20;
            this.bindingNavigator3.MoveNextItem = this.toolStripButton19;
            this.bindingNavigator3.MovePreviousItem = this.toolStripButton18;
            this.bindingNavigator3.Name = "bindingNavigator3";
            this.bindingNavigator3.PositionItem = this.toolStripTextBox3;
            this.bindingNavigator3.Size = new System.Drawing.Size(278, 25);
            this.bindingNavigator3.TabIndex = 4;
            this.bindingNavigator3.Text = "c";
            // 
            // toolStripButton15
            // 
            this.toolStripButton15.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton15.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton15.Image")));
            this.toolStripButton15.Name = "toolStripButton15";
            this.toolStripButton15.RightToLeftAutoMirrorImage = true;
            this.toolStripButton15.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton15.Text = "Adicionar novo";
            // 
            // toolStripLabel3
            // 
            this.toolStripLabel3.Name = "toolStripLabel3";
            this.toolStripLabel3.Size = new System.Drawing.Size(37, 22);
            this.toolStripLabel3.Text = "de {0}";
            this.toolStripLabel3.ToolTipText = "Número total de itens";
            // 
            // toolStripButton16
            // 
            this.toolStripButton16.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton16.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton16.Image")));
            this.toolStripButton16.Name = "toolStripButton16";
            this.toolStripButton16.RightToLeftAutoMirrorImage = true;
            this.toolStripButton16.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton16.Text = "Excluir";
            // 
            // toolStripButton17
            // 
            this.toolStripButton17.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton17.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton17.Image")));
            this.toolStripButton17.Name = "toolStripButton17";
            this.toolStripButton17.RightToLeftAutoMirrorImage = true;
            this.toolStripButton17.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton17.Text = "Mover primeiro";
            // 
            // toolStripButton18
            // 
            this.toolStripButton18.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton18.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton18.Image")));
            this.toolStripButton18.Name = "toolStripButton18";
            this.toolStripButton18.RightToLeftAutoMirrorImage = true;
            this.toolStripButton18.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton18.Text = "Mover anterior";
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripTextBox3
            // 
            this.toolStripTextBox3.AccessibleName = "Posição";
            this.toolStripTextBox3.AutoSize = false;
            this.toolStripTextBox3.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.toolStripTextBox3.Name = "toolStripTextBox3";
            this.toolStripTextBox3.Size = new System.Drawing.Size(50, 23);
            this.toolStripTextBox3.Text = "0";
            this.toolStripTextBox3.ToolTipText = "Posição atual";
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton19
            // 
            this.toolStripButton19.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton19.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton19.Image")));
            this.toolStripButton19.Name = "toolStripButton19";
            this.toolStripButton19.RightToLeftAutoMirrorImage = true;
            this.toolStripButton19.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton19.Text = "Mover próximo";
            // 
            // toolStripButton20
            // 
            this.toolStripButton20.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton20.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton20.Image")));
            this.toolStripButton20.Name = "toolStripButton20";
            this.toolStripButton20.RightToLeftAutoMirrorImage = true;
            this.toolStripButton20.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton20.Text = "Mover último";
            // 
            // toolStripSeparator9
            // 
            this.toolStripSeparator9.Name = "toolStripSeparator9";
            this.toolStripSeparator9.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton21
            // 
            this.toolStripButton21.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton21.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton21.Image")));
            this.toolStripButton21.Name = "toolStripButton21";
            this.toolStripButton21.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton21.Text = "Salvar Dados";
            // 
            // tabPage5
            // 
            this.tabPage5.AutoScroll = true;
            this.tabPage5.Controls.Add(this.button19);
            this.tabPage5.Controls.Add(this.button20);
            this.tabPage5.Controls.Add(this.button21);
            this.tabPage5.Controls.Add(this.button13);
            this.tabPage5.Controls.Add(this.button14);
            this.tabPage5.Controls.Add(this.button15);
            this.tabPage5.Controls.Add(categoriaMotLabel);
            this.tabPage5.Controls.Add(this.categoriaMotTextBox);
            this.tabPage5.Controls.Add(this.bindingNavigator4);
            this.tabPage5.Controls.Add(label7);
            this.tabPage5.Controls.Add(this.textBox7);
            this.tabPage5.Controls.Add(label8);
            this.tabPage5.Controls.Add(this.textBox8);
            this.tabPage5.Controls.Add(label9);
            this.tabPage5.Controls.Add(this.textBox9);
            this.tabPage5.Controls.Add(label10);
            this.tabPage5.Controls.Add(this.textBox10);
            this.tabPage5.Controls.Add(label1);
            this.tabPage5.Controls.Add(this.textBox1);
            this.tabPage5.Controls.Add(label2);
            this.tabPage5.Controls.Add(this.textBox2);
            this.tabPage5.Controls.Add(label3);
            this.tabPage5.Controls.Add(this.textBox3);
            this.tabPage5.Controls.Add(label4);
            this.tabPage5.Controls.Add(this.textBox4);
            this.tabPage5.Controls.Add(label5);
            this.tabPage5.Controls.Add(this.textBox5);
            this.tabPage5.Controls.Add(label6);
            this.tabPage5.Controls.Add(this.textBox6);
            this.tabPage5.Controls.Add(label11);
            this.tabPage5.Controls.Add(this.textBox11);
            this.tabPage5.Controls.Add(label12);
            this.tabPage5.Controls.Add(this.textBox12);
            this.tabPage5.Controls.Add(label13);
            this.tabPage5.Controls.Add(this.dateTimePicker1);
            this.tabPage5.Controls.Add(label14);
            this.tabPage5.Controls.Add(this.dateTimePicker2);
            this.tabPage5.Controls.Add(label15);
            this.tabPage5.Controls.Add(this.textBox13);
            this.tabPage5.Location = new System.Drawing.Point(4, 26);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(792, 449);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Dados Cadastrais";
            this.tabPage5.UseVisualStyleBackColor = true;
            this.tabPage5.Click += new System.EventHandler(this.tabPage5_Click);
            // 
            // button13
            // 
            this.button13.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button13.BackColor = System.Drawing.Color.LightGray;
            this.button13.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button13.Location = new System.Drawing.Point(592, 451);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(100, 25);
            this.button13.TabIndex = 144;
            this.button13.Text = "Confirmar";
            this.button13.UseVisualStyleBackColor = false;
            // 
            // button14
            // 
            this.button14.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button14.BackColor = System.Drawing.Color.LightGray;
            this.button14.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button14.Location = new System.Drawing.Point(485, 451);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(100, 25);
            this.button14.TabIndex = 143;
            this.button14.Text = "Voltar";
            this.button14.UseVisualStyleBackColor = false;
            // 
            // button15
            // 
            this.button15.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button15.BackColor = System.Drawing.Color.LightGray;
            this.button15.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button15.Location = new System.Drawing.Point(75, 451);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(100, 25);
            this.button15.TabIndex = 142;
            this.button15.Text = "Sair";
            this.button15.UseVisualStyleBackColor = false;
            // 
            // categoriaMotTextBox
            // 
            this.categoriaMotTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewApolicesClientesBindingSource, "CategoriaMot", true));
            this.categoriaMotTextBox.Location = new System.Drawing.Point(189, 356);
            this.categoriaMotTextBox.Name = "categoriaMotTextBox";
            this.categoriaMotTextBox.Size = new System.Drawing.Size(197, 25);
            this.categoriaMotTextBox.TabIndex = 141;
            this.categoriaMotTextBox.TextChanged += new System.EventHandler(this.categoriaMotTextBox_TextChanged);
            // 
            // bindingNavigator4
            // 
            this.bindingNavigator4.AddNewItem = this.toolStripButton22;
            this.bindingNavigator4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.bindingNavigator4.BindingSource = this.viewApolicesClientesBindingSource;
            this.bindingNavigator4.CountItem = this.toolStripLabel4;
            this.bindingNavigator4.DeleteItem = this.toolStripButton23;
            this.bindingNavigator4.Dock = System.Windows.Forms.DockStyle.None;
            this.bindingNavigator4.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton24,
            this.toolStripButton25,
            this.toolStripSeparator10,
            this.toolStripTextBox4,
            this.toolStripLabel4,
            this.toolStripSeparator11,
            this.toolStripButton26,
            this.toolStripButton27,
            this.toolStripSeparator12,
            this.toolStripButton22,
            this.toolStripButton23,
            this.toolStripButton28});
            this.bindingNavigator4.Location = new System.Drawing.Point(1, 0);
            this.bindingNavigator4.MoveFirstItem = this.toolStripButton24;
            this.bindingNavigator4.MoveLastItem = this.toolStripButton27;
            this.bindingNavigator4.MoveNextItem = this.toolStripButton26;
            this.bindingNavigator4.MovePreviousItem = this.toolStripButton25;
            this.bindingNavigator4.Name = "bindingNavigator4";
            this.bindingNavigator4.PositionItem = this.toolStripTextBox4;
            this.bindingNavigator4.Size = new System.Drawing.Size(278, 25);
            this.bindingNavigator4.TabIndex = 140;
            this.bindingNavigator4.Text = "c";
            // 
            // toolStripButton22
            // 
            this.toolStripButton22.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton22.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton22.Image")));
            this.toolStripButton22.Name = "toolStripButton22";
            this.toolStripButton22.RightToLeftAutoMirrorImage = true;
            this.toolStripButton22.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton22.Text = "Adicionar novo";
            // 
            // toolStripLabel4
            // 
            this.toolStripLabel4.Name = "toolStripLabel4";
            this.toolStripLabel4.Size = new System.Drawing.Size(37, 22);
            this.toolStripLabel4.Text = "de {0}";
            this.toolStripLabel4.ToolTipText = "Número total de itens";
            // 
            // toolStripButton23
            // 
            this.toolStripButton23.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton23.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton23.Image")));
            this.toolStripButton23.Name = "toolStripButton23";
            this.toolStripButton23.RightToLeftAutoMirrorImage = true;
            this.toolStripButton23.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton23.Text = "Excluir";
            // 
            // toolStripButton24
            // 
            this.toolStripButton24.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton24.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton24.Image")));
            this.toolStripButton24.Name = "toolStripButton24";
            this.toolStripButton24.RightToLeftAutoMirrorImage = true;
            this.toolStripButton24.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton24.Text = "Mover primeiro";
            // 
            // toolStripButton25
            // 
            this.toolStripButton25.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton25.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton25.Image")));
            this.toolStripButton25.Name = "toolStripButton25";
            this.toolStripButton25.RightToLeftAutoMirrorImage = true;
            this.toolStripButton25.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton25.Text = "Mover anterior";
            // 
            // toolStripSeparator10
            // 
            this.toolStripSeparator10.Name = "toolStripSeparator10";
            this.toolStripSeparator10.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripTextBox4
            // 
            this.toolStripTextBox4.AccessibleName = "Posição";
            this.toolStripTextBox4.AutoSize = false;
            this.toolStripTextBox4.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.toolStripTextBox4.Name = "toolStripTextBox4";
            this.toolStripTextBox4.Size = new System.Drawing.Size(50, 23);
            this.toolStripTextBox4.Text = "0";
            this.toolStripTextBox4.ToolTipText = "Posição atual";
            // 
            // toolStripSeparator11
            // 
            this.toolStripSeparator11.Name = "toolStripSeparator11";
            this.toolStripSeparator11.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton26
            // 
            this.toolStripButton26.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton26.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton26.Image")));
            this.toolStripButton26.Name = "toolStripButton26";
            this.toolStripButton26.RightToLeftAutoMirrorImage = true;
            this.toolStripButton26.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton26.Text = "Mover próximo";
            // 
            // toolStripButton27
            // 
            this.toolStripButton27.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton27.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton27.Image")));
            this.toolStripButton27.Name = "toolStripButton27";
            this.toolStripButton27.RightToLeftAutoMirrorImage = true;
            this.toolStripButton27.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton27.Text = "Mover último";
            // 
            // toolStripSeparator12
            // 
            this.toolStripSeparator12.Name = "toolStripSeparator12";
            this.toolStripSeparator12.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton28
            // 
            this.toolStripButton28.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton28.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton28.Image")));
            this.toolStripButton28.Name = "toolStripButton28";
            this.toolStripButton28.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton28.Text = "Salvar Dados";
            // 
            // textBox7
            // 
            this.textBox7.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewApolicesClientesBindingSource, "Telefone", true));
            this.textBox7.Location = new System.Drawing.Point(539, 145);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(200, 25);
            this.textBox7.TabIndex = 133;
            // 
            // textBox8
            // 
            this.textBox8.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewApolicesClientesBindingSource, "Celular", true));
            this.textBox8.Location = new System.Drawing.Point(539, 176);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(200, 25);
            this.textBox8.TabIndex = 135;
            // 
            // textBox9
            // 
            this.textBox9.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewApolicesClientesBindingSource, "CPF", true));
            this.textBox9.Location = new System.Drawing.Point(539, 42);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(200, 25);
            this.textBox9.TabIndex = 137;
            // 
            // textBox10
            // 
            this.textBox10.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewApolicesClientesBindingSource, "RG", true));
            this.textBox10.Location = new System.Drawing.Point(539, 73);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(200, 25);
            this.textBox10.TabIndex = 139;
            // 
            // textBox1
            // 
            this.textBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewApolicesClientesBindingSource, "ClienteId", true));
            this.textBox1.Location = new System.Drawing.Point(186, 44);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(200, 25);
            this.textBox1.TabIndex = 103;
            // 
            // textBox2
            // 
            this.textBox2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewApolicesClientesBindingSource, "Nome", true));
            this.textBox2.Location = new System.Drawing.Point(186, 88);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(200, 25);
            this.textBox2.TabIndex = 105;
            // 
            // textBox3
            // 
            this.textBox3.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewApolicesClientesBindingSource, "Endereco", true));
            this.textBox3.Location = new System.Drawing.Point(186, 119);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(200, 25);
            this.textBox3.TabIndex = 107;
            // 
            // textBox4
            // 
            this.textBox4.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewApolicesClientesBindingSource, "CEP", true));
            this.textBox4.Location = new System.Drawing.Point(186, 150);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(200, 25);
            this.textBox4.TabIndex = 109;
            // 
            // textBox5
            // 
            this.textBox5.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewApolicesClientesBindingSource, "Cidade", true));
            this.textBox5.Location = new System.Drawing.Point(186, 181);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(200, 25);
            this.textBox5.TabIndex = 111;
            // 
            // textBox6
            // 
            this.textBox6.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewApolicesClientesBindingSource, "UF", true));
            this.textBox6.Location = new System.Drawing.Point(186, 212);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(200, 25);
            this.textBox6.TabIndex = 113;
            // 
            // textBox11
            // 
            this.textBox11.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewApolicesClientesBindingSource, "OrgaoEmissor", true));
            this.textBox11.Location = new System.Drawing.Point(539, 107);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(200, 25);
            this.textBox11.TabIndex = 123;
            // 
            // textBox12
            // 
            this.textBox12.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewApolicesClientesBindingSource, "CartMotorista", true));
            this.textBox12.Location = new System.Drawing.Point(186, 292);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(200, 25);
            this.textBox12.TabIndex = 125;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.viewApolicesClientesBindingSource, "EmissaoCartMot", true));
            this.dateTimePicker1.Location = new System.Drawing.Point(186, 323);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 25);
            this.dateTimePicker1.TabIndex = 127;
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.viewApolicesClientesBindingSource, "DataNascimento", true));
            this.dateTimePicker2.Location = new System.Drawing.Point(539, 292);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(200, 25);
            this.dateTimePicker2.TabIndex = 129;
            // 
            // textBox13
            // 
            this.textBox13.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewApolicesClientesBindingSource, "Email", true));
            this.textBox13.Location = new System.Drawing.Point(539, 323);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(200, 25);
            this.textBox13.TabIndex = 131;
            // 
            // apolicesBindingSource
            // 
            this.apolicesBindingSource.DataMember = "Apolices";
            this.apolicesBindingSource.DataSource = this.corretoraDataSet;
            // 
            // viewModelosMarcasBindingSource
            // 
            this.viewModelosMarcasBindingSource.DataMember = "ViewModelosMarcas";
            this.viewModelosMarcasBindingSource.DataSource = this.corretoraDataSet;
            // 
            // apolicesTableAdapter
            // 
            this.apolicesTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.ApolicesTableAdapter = this.apolicesTableAdapter;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.ClientesTableAdapter = null;
            this.tableAdapterManager.MarcaTableAdapter = null;
            this.tableAdapterManager.ModeloTableAdapter = null;
            this.tableAdapterManager.TabelaFIPETableAdapter = null;
            this.tableAdapterManager.UpdateOrder = ProjetoFinalDesktop2.CorretoraDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // marcaBindingSource
            // 
            this.marcaBindingSource.DataMember = "Marca";
            this.marcaBindingSource.DataSource = this.corretoraDataSet;
            // 
            // marcaTableAdapter
            // 
            this.marcaTableAdapter.ClearBeforeFill = true;
            // 
            // modeloBindingSource
            // 
            this.modeloBindingSource.DataMember = "Modelo";
            this.modeloBindingSource.DataSource = this.corretoraDataSet;
            // 
            // modeloTableAdapter
            // 
            this.modeloTableAdapter.ClearBeforeFill = true;
            // 
            // viewModelosMarcasTableAdapter
            // 
            this.viewModelosMarcasTableAdapter.ClearBeforeFill = true;
            // 
            // viewApolicesClientesTableAdapter
            // 
            this.viewApolicesClientesTableAdapter.ClearBeforeFill = true;
            // 
            // button16
            // 
            this.button16.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button16.BackColor = System.Drawing.Color.LightGray;
            this.button16.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button16.Location = new System.Drawing.Point(568, 293);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(100, 25);
            this.button16.TabIndex = 68;
            this.button16.Text = "Avançar";
            this.button16.UseVisualStyleBackColor = false;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // button17
            // 
            this.button17.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button17.BackColor = System.Drawing.Color.LightGray;
            this.button17.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button17.Location = new System.Drawing.Point(461, 293);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(100, 25);
            this.button17.TabIndex = 67;
            this.button17.Text = "Voltar";
            this.button17.UseVisualStyleBackColor = false;
            this.button17.Click += new System.EventHandler(this.button17_Click);
            // 
            // button18
            // 
            this.button18.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button18.BackColor = System.Drawing.Color.LightGray;
            this.button18.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button18.Location = new System.Drawing.Point(51, 293);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(100, 25);
            this.button18.TabIndex = 66;
            this.button18.Text = "Sair";
            this.button18.UseVisualStyleBackColor = false;
            this.button18.Click += new System.EventHandler(this.button18_Click);
            // 
            // button19
            // 
            this.button19.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button19.BackColor = System.Drawing.Color.LightGray;
            this.button19.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button19.Location = new System.Drawing.Point(583, 403);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(100, 25);
            this.button19.TabIndex = 147;
            this.button19.Text = "Confirmar";
            this.button19.UseVisualStyleBackColor = false;
            this.button19.Click += new System.EventHandler(this.button19_Click_1);
            // 
            // button20
            // 
            this.button20.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button20.BackColor = System.Drawing.Color.LightGray;
            this.button20.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button20.Location = new System.Drawing.Point(476, 403);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(100, 25);
            this.button20.TabIndex = 146;
            this.button20.Text = "Voltar";
            this.button20.UseVisualStyleBackColor = false;
            // 
            // button21
            // 
            this.button21.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button21.BackColor = System.Drawing.Color.LightGray;
            this.button21.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button21.Location = new System.Drawing.Point(66, 403);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(100, 25);
            this.button21.TabIndex = 145;
            this.button21.Text = "Sair";
            this.button21.UseVisualStyleBackColor = false;
            // 
            // Simulacao
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(805, 481);
            this.Controls.Add(this.tabControl1);
            this.Name = "Simulacao";
            this.Text = "Simulacao";
            this.Load += new System.EventHandler(this.Simulacao_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.viewApolicesClientesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.corretoraDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.apolicesBindingNavigator)).EndInit();
            this.apolicesBindingNavigator.ResumeLayout(false);
            this.apolicesBindingNavigator.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator1)).EndInit();
            this.bindingNavigator1.ResumeLayout(false);
            this.bindingNavigator1.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator2)).EndInit();
            this.bindingNavigator2.ResumeLayout(false);
            this.bindingNavigator2.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator3)).EndInit();
            this.bindingNavigator3.ResumeLayout(false);
            this.bindingNavigator3.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator4)).EndInit();
            this.bindingNavigator4.ResumeLayout(false);
            this.bindingNavigator4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.apolicesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewModelosMarcasBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.marcaBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.modeloBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private CorretoraDataSet corretoraDataSet;
        private System.Windows.Forms.BindingSource apolicesBindingSource;
        private CorretoraDataSetTableAdapters.ApolicesTableAdapter apolicesTableAdapter;
        private CorretoraDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator apolicesBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton apolicesBindingNavigatorSaveItem;
        private System.Windows.Forms.BindingNavigator bindingNavigator1;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripLabel toolStripLabel1;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBox1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton toolStripButton5;
        private System.Windows.Forms.ToolStripButton toolStripButton6;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton toolStripButton7;
        private System.Windows.Forms.BindingNavigator bindingNavigator2;
        private System.Windows.Forms.ToolStripButton toolStripButton8;
        private System.Windows.Forms.ToolStripLabel toolStripLabel2;
        private System.Windows.Forms.ToolStripButton toolStripButton9;
        private System.Windows.Forms.ToolStripButton toolStripButton10;
        private System.Windows.Forms.ToolStripButton toolStripButton11;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBox2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripButton toolStripButton12;
        private System.Windows.Forms.ToolStripButton toolStripButton13;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripButton toolStripButton14;
        private System.Windows.Forms.BindingNavigator bindingNavigator3;
        private System.Windows.Forms.ToolStripButton toolStripButton15;
        private System.Windows.Forms.ToolStripLabel toolStripLabel3;
        private System.Windows.Forms.ToolStripButton toolStripButton16;
        private System.Windows.Forms.ToolStripButton toolStripButton17;
        private System.Windows.Forms.ToolStripButton toolStripButton18;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBox3;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
        private System.Windows.Forms.ToolStripButton toolStripButton19;
        private System.Windows.Forms.ToolStripButton toolStripButton20;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator9;
        private System.Windows.Forms.ToolStripButton toolStripButton21;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.BindingSource marcaBindingSource;
        private CorretoraDataSetTableAdapters.MarcaTableAdapter marcaTableAdapter;
        private System.Windows.Forms.BindingSource modeloBindingSource;
        private CorretoraDataSetTableAdapters.ModeloTableAdapter modeloTableAdapter;
        private System.Windows.Forms.BindingSource viewModelosMarcasBindingSource;
        private CorretoraDataSetTableAdapters.ViewModelosMarcasTableAdapter viewModelosMarcasTableAdapter;
        private System.Windows.Forms.BindingSource viewApolicesClientesBindingSource;
        private CorretoraDataSetTableAdapters.ViewApolicesClientesTableAdapter viewApolicesClientesTableAdapter;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TextBox apoliceIdTextBox;
        private System.Windows.Forms.TextBox marcaTextBox;
        private System.Windows.Forms.TextBox modeloTextBox;
        private System.Windows.Forms.TextBox anoFabricacaoTextBox;
        private System.Windows.Forms.TextBox anoModeloTextBox;
        private System.Windows.Forms.TextBox valorDoBemTextBox2;
        private System.Windows.Forms.TextBox combustivelTextBox2;
        private System.Windows.Forms.TextBox chassiTextBox2;
        private System.Windows.Forms.TextBox placaTextBox2;
        private System.Windows.Forms.CheckBox rouboCheckBox2;
        private System.Windows.Forms.CheckBox vidrosCheckBox2;
        private System.Windows.Forms.CheckBox acidentesCheckBox2;
        private System.Windows.Forms.CheckBox danosTerceirosCheckBox2;
        private System.Windows.Forms.CheckBox franquiaRedCheckBox2;
        private System.Windows.Forms.TextBox valorFranquiaTextBox2;
        private System.Windows.Forms.TextBox valorApoliceTextBox2;
        private System.Windows.Forms.TextBox valorPremioTextBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.BindingNavigator bindingNavigator4;
        private System.Windows.Forms.ToolStripButton toolStripButton22;
        private System.Windows.Forms.ToolStripLabel toolStripLabel4;
        private System.Windows.Forms.ToolStripButton toolStripButton23;
        private System.Windows.Forms.ToolStripButton toolStripButton24;
        private System.Windows.Forms.ToolStripButton toolStripButton25;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator10;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBox4;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator11;
        private System.Windows.Forms.ToolStripButton toolStripButton26;
        private System.Windows.Forms.ToolStripButton toolStripButton27;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator12;
        private System.Windows.Forms.ToolStripButton toolStripButton28;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox categoriaMotTextBox;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button21;
    }
}